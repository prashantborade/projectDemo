//
//  viewModel.swift
//  MVVMNewDemo
//
//  Created by MAC-PC on 15/01/18.
//  Copyright © 2018 Chitra Sambare. All rights reserved.
//

import UIKit

class viewModel: NSObject {
  
  var movies: [NSDictionary]?
 @IBOutlet var moviesClient: MoviesClient!
  
  func fetchMovies(completion: @escaping () -> ()) {
    moviesClient.fetchMovies { movies in
      self.movies = movies
      completion()
    }
  }
  
  func numberOfItemsInSection(section: Int) -> Int {
    return movies?.count ?? 0
  }
  
  func titleForItemAtIndexPath(indexPath: NSIndexPath) -> String {
    return movies?[indexPath.row].value(forKeyPath: "im:name.label") as? String ?? ""
  }

}
