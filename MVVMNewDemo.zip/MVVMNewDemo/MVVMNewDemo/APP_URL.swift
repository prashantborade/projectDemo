//
//  APP_URL.swift
//  MVVMNewDemo
//
//  Created by MAC-PC on 15/01/18.
//  Copyright © 2018 Chitra Sambare. All rights reserved.
//

import Foundation

internal struct APP_URL {
  
 static let urlString = "https://itunes.apple.com/us/rss/topmovies/limit=25/json"
  
}
