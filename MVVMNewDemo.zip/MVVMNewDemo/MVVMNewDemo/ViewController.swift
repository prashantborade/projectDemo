//
//  ViewController.swift
//  MVVMNewDemo
//
//  Created by MAC-PC on 15/01/18.
//  Copyright © 2018 Chitra Sambare. All rights reserved.
//

import UIKit


class ViewController: UIViewController, UITableViewDataSource {

  @IBOutlet var tableView: UITableView!
  @IBOutlet var viewModel : viewModel!
  override func viewDidLoad() {
    super.viewDidLoad()
    viewModel.fetchMovies {
      DispatchQueue.main.async(execute: {
            self.tableView.reloadData()
      })
    }
  }

  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return viewModel.numberOfItemsInSection(section: section)
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
    
    configureCell(cell: cell,forRowIndexPath: indexPath as NSIndexPath)
    
    return cell
  }
  
  func configureCell(cell: UITableViewCell, forRowIndexPath indexPath: NSIndexPath){
    cell.textLabel?.text = viewModel.titleForItemAtIndexPath(indexPath: indexPath)
  }
}

