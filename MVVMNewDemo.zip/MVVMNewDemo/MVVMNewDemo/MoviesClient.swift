//
//  MoviesClient.swift
//  MVVMNewDemo
//
//  Created by MAC-PC on 15/01/18.
//  Copyright © 2018 Chitra Sambare. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class MoviesClient: NSObject {

  func fetchMovies(completion: @escaping ([NSDictionary]) -> ()) {
    
    let request = URLRequest(url: URL(string: APP_URL.urlString)!)
    
    Alamofire.request(request).responseJSON { response in
      
      UIApplication.shared.isNetworkActivityIndicatorVisible = false
      switch response.result
      {
      case .failure:
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        DispatchQueue.main.async (execute: {
          print("Error Occured")
          return
        })
        
      case .success:
        print("In success")
        let json = response.result.value as? NSDictionary
        let movies = json?.value(forKeyPath: "feed.entry") as? [NSDictionary]
        completion(movies!)
        return
      }
      
    }

  }
}
