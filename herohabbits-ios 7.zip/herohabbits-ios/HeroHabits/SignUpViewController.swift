//
//  SignUpViewController.swift
//  HeroHabits
//
//  Created by aspl on 25/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import SVProgressHUD
import Alamofire
import SwiftyJSON
import GoogleSignIn

class SignUpViewController: UIViewController,UITextFieldDelegate,GIDSignInUIDelegate,GIDSignInDelegate,UIPickerViewDelegate{
    var isLoginFrom: String = ""
    var tField: UITextField!
    var termsAndConditions:Bool = false
    
    @IBOutlet var kgModelView: UIView!
    @IBOutlet weak var btnSignIn: UIButton!
    
    @IBOutlet weak var txtDateOfBirth: TextField!
    @IBOutlet weak var txtFirstname: TextField!
    @IBOutlet weak var txtLastname: TextField!
    @IBOutlet weak var txtUsername: TextField!
    @IBOutlet weak var txtEmailAddress: TextField!
    @IBOutlet weak var txtPhoneNumber: TextField!
    @IBOutlet weak var txtPassword: TextField!
    @IBOutlet weak var txtConfirmPassword: TextField!
    
    @IBOutlet weak var btnCheckbox: UIButton!
    @IBOutlet weak var lblTermsNConditions: UILabel!
    
    
    @IBOutlet weak var heightOfSignUp: NSLayoutConstraint!
    @IBOutlet weak var heightOfSignInView: NSLayoutConstraint!
    @IBOutlet weak var heightOfSignUpView: NSLayoutConstraint!
    @IBOutlet weak var heightOfSocialView: NSLayoutConstraint!
    @IBOutlet weak var widthOfSocialView: NSLayoutConstraint!
    @IBOutlet weak var verticalSpaceOfsigIn: NSLayoutConstraint!
    @IBOutlet weak var heightOfTxtField: NSLayoutConstraint!
    @IBOutlet weak var heightOfImage: NSLayoutConstraint!
    @IBOutlet weak var heightOfButton: NSLayoutConstraint!
    @IBOutlet weak var widthOfImage: NSLayoutConstraint!
    @IBOutlet weak var heightOfGoogle: NSLayoutConstraint!
    @IBOutlet weak var widthOfGoogle: NSLayoutConstraint!
    @IBOutlet weak var heightOfTwitter: NSLayoutConstraint!
    @IBOutlet weak var widthOfTwitter: NSLayoutConstraint!
    @IBOutlet weak var lblSignIn: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       navigationController?.navigationBar.isHidden = true
        txtPhoneNumber.delegate = self
      
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(SignUpViewController.tapFunction))
        lblTermsNConditions.isUserInteractionEnabled = true
        lblTermsNConditions.addGestureRecognizer(tap)
   
        let datePicker = UIDatePicker()

        datePicker.date = Date()
        
        datePicker.datePickerMode = .date
        
        datePicker.addTarget(self, action: #selector(self.dateTextField(_:)), for: .valueChanged)
        txtDateOfBirth.inputView = datePicker
    
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
            if DeviceType.iPhoneX{
                heightOfSignUpView.constant = 210
            }else if DeviceType.iPhone5orSE{
                heightOfSignUpView.constant = 440
            }else if DeviceType.iPhone678{
                heightOfSignUpView.constant = 345
            }else if DeviceType.iPhone678p{
                heightOfSignUpView.constant = 280
            }
            break
       
        case .pad:
            if DeviceType.IS_IPAD_PRO{
                
                heightOfImage.constant = 250
                widthOfImage.constant = 250
                heightOfTxtField.constant = 50
                heightOfButton.constant = 50
               
                heightOfGoogle.constant = 80
                widthOfGoogle.constant = 60
                heightOfTwitter.constant = 80
                widthOfTwitter.constant = 60
                heightOfSocialView.constant = 84
                widthOfSocialView.constant = 200
                
               
            }
            break
        
        case .unspecified: break
           
        case .tv:
            break
        case .carPlay:
            break
        }
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
            if DeviceType.iPhone4orLess{
                kgModelView.frame = CGRect(x: 0.0, y: 0.0, width:300.0 , height: 440.0 )
            }else if DeviceType.iPhone5orSE{
                kgModelView.frame = CGRect(x: 0.0, y: 0.0, width: 300.0, height:520.0 )
            }else if DeviceType.iPhone678{
                kgModelView.frame = CGRect(x: 0.0, y: 0.0, width: 350.0, height: 620.0)
            }else if DeviceType.iPhone678p{
                kgModelView.frame = CGRect(x: 0.0, y: 0.0, width: 370.0, height: 650.0)
            }else if DeviceType.iPhoneX{
                kgModelView.frame = CGRect(x: 0.0, y: 0.0, width: 350.0, height: 720.0)
            }
            break
        case .pad:
            if DeviceType.IS_IPAD{
                kgModelView.frame = CGRect(x: 0.0, y: 0.0, width: 740.0, height: 950.0)
            }else if DeviceType.IS_IPAD_PRO{
                kgModelView.frame = CGRect(x: 0.0, y: 0.0, width: 740.0, height: 950.0)
            }else{
                kgModelView.frame = CGRect(x: 0.0, y: 0.0, width: view.frame.size.width, height: view.frame.size.height)
            }
            break
        case .unspecified:
            break
        case .tv:
            break
        case .carPlay:
            break
        }
       
        lblSignIn.text = "Existing User ? Sign In"
        let text = (lblSignIn.text)!
        let underlineAttriString = NSMutableAttributedString(string: text)
        let range1 = (text as NSString).range(of: "Sign In")
        underlineAttriString.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.white , range: range1)
        lblSignIn.attributedText = underlineAttriString
        
        let tapSigIn = UITapGestureRecognizer(target: self, action: #selector(SignUpViewController.tapSigIn))
        lblSignIn.isUserInteractionEnabled = true
        lblSignIn.addGestureRecognizer(tapSigIn)
    }
    
    @objc func dateTextField(_ sender: Any?) {
        
        
        let picker = txtDateOfBirth.inputView as? UIDatePicker
        picker?.maximumDate = Date()
        let dateFormat = DateFormatter()
        let eventDate: Date? = picker?.date
        dateFormat.dateFormat = "yyyy-MM-dd"
        
        var dateString: String? = nil
        if let aDate = eventDate {
            dateString = dateFormat.string(from: aDate)
        }
        txtDateOfBirth.text = "\(dateString ?? "")"
    }
    @objc
    func tapFunction(sender:UITapGestureRecognizer) {
        KGModal.sharedInstance().show(withContentView: self.kgModelView, andAnimated: true)
        KGModal.sharedInstance().closeButtonType = .left
        KGModal.sharedInstance().tapOutsideToDismiss = true
        KGModal.sharedInstance().modalBackgroundColor = UIColor.white
    }
    @objc func tapSigIn(sender:UITapGestureRecognizer){
        let text = (lblSignIn.text)!
        let termsRange = (text as NSString).range(of: "Sign In")
        
        if sender.didTapAttributedTextInLabel(label: lblSignIn, inRange: termsRange) {
            print("Tapped terms")
            self.navigationController?.popViewController(animated: true)
        }else {
            print("Tapped none")
        }
    }
    @IBAction func tapLabel(gesture: UITapGestureRecognizer) {
        let text = (lblSignIn.text)!
        let termsRange = (text as NSString).range(of: "SignIn")
 
        if gesture.didTapAttributedTextInLabel(label: lblSignIn, inRange: termsRange) {
            print("Tapped SignIn")
        }else {
            print("Tapped none")
        }
    }

    @IBAction func btnCheckBoxTapped(_ sender: Any) {
        if ((sender as! UIButton).isSelected)
        {
            btnCheckbox.isSelected = false
            termsAndConditions = false
            print("one")
        }
        else
        {
            btnCheckbox.isSelected = true
            termsAndConditions = true
            print("Two")
        }
    }
    

    @IBAction func btnSignInTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSignUpTapped(_ sender: Any) {
        
        
        if (txtFirstname.text?.isEmpty)!{
            popupAlert(title: "Hero Habits", message: "Please Enter Your Firstname", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
//            let str = txtFirstname.text
//            let trimmed = str?.trimmingCharacters(in: .whitespacesAndNewlines)
        }else if (txtLastname.text?.isEmpty)!{
            popupAlert(title: "Hero Habits", message: "Please Enter Your Lastname", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtUsername.text?.isEmpty)!{
            popupAlert(title: "Hero Habits", message: "Please Enter Your Username", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtEmailAddress.text?.isEmpty)!{
            popupAlert(title: "Hero Habits", message: "Please Enter Your E-mail Address", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if !isValidEmail(testStr: txtEmailAddress.text!){
            popupAlert(title: "Hero Habits", message: "Please Enter Correct E-mail Address", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtPhoneNumber.text?.isEmpty)!{
            popupAlert(title: "Hero Habits", message: "Please Enter Your Phone Number", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if ((txtPassword.text?.count)! < 6){
            popupAlert(title: "Hero Habits", message: "Password must be more than 6 characters", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }
        else if (txtDateOfBirth.text?.isEmpty)!{
            popupAlert(title: "Hero Habits", message: "Please Enter Your Birth Date", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtPassword.text?.isEmpty)!{
            popupAlert(title: "Hero Habits", message: "Please Enter Your Password", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtPassword.text?.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil){
            popupAlert(title: "Hero Habit", message: "Password do not accept space as Password", actionTitles: ["Ok"], actions: [{(action1) in
                
                }])
        }
        else if (txtConfirmPassword.text?.isEmpty)!{
            popupAlert(title: "Hero Habits", message: "Please Enter Your Confirm Password", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }else if (txtConfirmPassword.text?.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil){
            popupAlert(title: "Hero Habit", message: "Password do not accept space as Password", actionTitles: ["Ok"], actions: [{(action1) in
                
                }])
        }
        else if !(txtPassword.text == txtConfirmPassword.text ) {
            popupAlert(title: "Hero Habits", message: "Password and Confirm Password does not Match", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
    
        }else if !termsAndConditions{
            popupAlert(title: "Hero Habits", message: "You must agree to the terms and conditions before registering", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
        }
        else{
          
            signUpCall()
        
        }

    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range:NSRange, replacementString string: String) -> Bool
    {
      
        let currentCharacterCount = txtPhoneNumber.text?.count ?? 0
        if (range.length + range.location > currentCharacterCount){
            return false
        }
        let newLength = currentCharacterCount + string.count - range.length
        return newLength <= 10
        
    }
    func verifyEmailCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.verifyemail)
    }
    
    
    func signUpCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.sign_up)
        
        let params = ["first_name":txtFirstname.text!,
                                  "last_name":txtLastname.text!,
                                  "email":txtEmailAddress.text!,
                                  "dob":txtDateOfBirth.text!,
                                  "password":txtConfirmPassword.text!,
                                  "username":txtUsername.text!,
                                  
                                  "login_type":"0"
        ]
        
        requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
            print(data)
            let status = data["status"].boolValue
            if !status{
                let message = data["message"].stringValue
                
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else{
                
                let userID = data["resultdata"]["user_id"].stringValue
                let username = data["resultdata"]["username"].stringValue
                UserDefaults.standard.set(userID, forKey: "userID")
                UserDefaults.standard.set(username, forKey: "userName")
                UserDefaults.standard.set(true, forKey: "mainController")
                 UserDefaults.standard.set("", forKey: "profileImage")
                
                let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                objAppDelegate?.gotoMainController()
            }
        }) { (error) in
            print(error)
        }
    }
    
    @IBAction func btnGoogleSignUp(_ sender: Any) {
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().signIn()
        isLoginFrom = "Google"
        UserDefaults.standard.set(isLoginFrom, forKey: "isLoginFrom")
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            print("\(error.localizedDescription)")
        } else {
            // Perform any operations on signed in user here.
            //            let userId = user.userID                  // For client-side use only!
            //           // let idToken = user.authentication.idToken // Safe to send to the server
            //            let fullName = user.profile.name
            //            let givenName = user.profile.givenName
            //            let familyName = user.profile.familyName
            //            let email = user.profile.email
            // ...
            
            let userId :String = user.userID                  // For client-side use only!
            // let idToken :String = user.authentication.idToken // Safe to send to the server
            
            let image :URL = user.profile.imageURL(withDimension: 1)
            // let profilUrl : String = String(image)
            let fullName :String = user.profile.name
            let givenName :String = user.profile.givenName
            let familyName :String = user.profile.familyName
            let email :String = user.profile.email
            
            print("email",email,"userid",userId, "userid",userId ,"fullName",fullName, "givenName",givenName,"familyName",familyName, "image",image )
        
                
                var url = webConstant.baseUrl
                url.append(webConstant.sign_up)
                
                let params:Dictionary  = ["first_name":givenName,
                                          "last_name":familyName,
                                          "email":email,
                                          "dob":"",
                                          "password":"",
                                          "username":givenName,
                                          "login_type":"4"]
                
                requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
                    print(data)
                    let status = data["status"].boolValue
                    let message = data["message"].stringValue
                    if !status{
                        self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                            
                            }])
                    }else{
                        
                        let username = data["resultdata"]["username"].stringValue
                        let userID = data["resultdata"]["user_id"].stringValue
                        let eamilID = data["resultdata"]["email"].stringValue
                        
                        UserDefaults.standard.set(userID, forKey: "userID")
                        UserDefaults.standard.set(username, forKey: "userName")
                        
                        if (eamilID.count == 0){
                            self.gettwittercall()
                        }else{
                            UserDefaults.standard.set(true, forKey: "mainController")
                            let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                            objAppDelegate?.gotoMainController()
                        }
                    }
                }) { (error) in
                    print(error)
                }
                
            
        }
    }
    
    func sign(_ signIn: GIDSignIn!,
              present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    private func signIn(signIn: GIDSignIn!,
                        dismissViewController viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnTwitterSignUp(_ sender: Any) {
        self.isLoginFrom = "Twitter"
        UserDefaults.standard.set(self.isLoginFrom, forKey: "isLoginFrom")
        if (UIApplication.shared.canOpenURL(URL(string:"twitter://")!)) {
        
        TWTRTwitter.sharedInstance().logIn(completion: { (session, error) in
            if (session != nil) {
                print("signed in as \(String(describing: session?.userName))");
                
            
                    var url = webConstant.baseUrl
                    url.append(webConstant.sign_up)
                    
                    let params:Dictionary  = ["first_name":"",
                                              "last_name":"",
                                              "email":"",
                                              "dob":"",
                                              "password":"",
                                              "username":(session?.userName)!,
                                              "login_type":"3"]
                    
                    print("params",params)
                    requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
                        print(data)
                        let status = data["status"].boolValue
                        let message = data["message"].stringValue
                        if !status{
                            self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                                
                                }])
                        }else{
                            let username = data["resultdata"]["username"].stringValue
                            let userID = data["resultdata"]["user_id"].stringValue
                            let eamilID = data["resultdata"]["email"].stringValue
                            
                            UserDefaults.standard.set(userID, forKey: "userID")
                            UserDefaults.standard.set(username, forKey: "userName")
                            
                            if (eamilID.count == 0){
                                self.gettwittercall()
                            }else{
                                UserDefaults.standard.set(true, forKey: "mainController")
                                let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                                objAppDelegate?.gotoMainController()
                            }
                        }
                    }, failure: { (error) in
                        print(error)
                    })
               
            } else {
                self.popupAlert(title: "Hero Habit", message: String(describing: error!.localizedDescription), actionTitles: ["Ok"], actions: [{ (action1) in
                    
                    }])
                print("error: \(String(describing: error?.localizedDescription))");
            }
        })
        }else{
            self.popupAlert(title: "Hero Habit", message: "Please,install twitter app.", actionTitles: ["Ok"], actions: [{ (action1) in
                
                }])
        }
    }
    func gettwittercall()
    {
        func configurationTextField(textField: UITextField!)
        {
            print("generating the TextField")
            textField.placeholder = "Enter an Email id"
            self.tField = textField
        }
        
        func handleCancel(alertView: UIAlertAction!)
        {
            print("Cancelled !!")
        }
        
        let alert = UIAlertController(title: "Enter Email address", message: "", preferredStyle: .alert)
        alert.addTextField(configurationHandler: configurationTextField)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler:handleCancel))
        alert.addAction(UIAlertAction(title: "Done", style: .default, handler:{ (UIAlertAction) in
            print("Done !!")
            
            if(!self.isValidEmail(testStr:  self.tField.text!))
            {
                self.popupAlert(title: "Hero Habits", message: "Please Enter Correct E-mail Address", actionTitles: ["Ok"], actions: [{ (action1) in
                    print("ok")
                    },{(action2) in
                        print("ok2")
                    }])
                
            }else{
                self.serviceCall()
            }
        }))
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }
    
    func serviceCall(){
        
        print("emailId : \(String(describing: self.tField.text))")
        let emailId : String = self.tField.text!
       
            var url = webConstant.baseUrl
            url.append(webConstant.update_email)
            
            let user_id = UserDefaults.standard.value(forKey: "userID") as! String
            let params = ["email":emailId,
                                       "id":user_id]
            requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
                print(data)
                let resp = data["resp"].boolValue
                let message = data["message"].stringValue
                if !resp{
                    self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                        
                        }])
                }else{
                    let userID = data["result"]["user_id"].stringValue
                    let username = data["result"]["username"].stringValue
                    
                    UserDefaults.standard.set(userID, forKey: "userID")
                    UserDefaults.standard.set(username, forKey: "userName")
                    UserDefaults.standard.set(true, forKey: "mainController")
                    
                    let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                    objAppDelegate?.gotoMainController()
                }
            }) { (error) in
                print(error)
            }
     
    }
   
}
