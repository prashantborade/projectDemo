//
//  PointsViewController.swift
//  HeroHabits
//
//  Created by aspl on 31/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class PointsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBar.barTintColor = UIColor.black
        navigationController?.navigationBar.tintColor = UIColor.white
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.white]
        view.backgroundColor = UIColor.white
        title = "Points and Frequency"
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
    }
}
