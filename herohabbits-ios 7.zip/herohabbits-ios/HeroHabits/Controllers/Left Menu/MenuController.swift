//
//  MenuController.swift
//  HeroHabits
//
//  Created by aspl on 29/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import SlideMenuControllerSwift
import GoogleSignIn


enum LeftMenu: Int {
    case main = 0
    case H_Order
    case summrie
    case referFriend
    case setting
    case special
    case exit
   
}

protocol LeftMenuProtocol : class {
    func changeViewController(_ menu: LeftMenu)
}

class MenuController: UIViewController,UITableViewDataSource, UITableViewDelegate,SlideMenuControllerDelegate {
   
    
    
    @IBOutlet weak var lblProfilename: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBAction func btnDismissTapped(_ sender: Any)
    {
        closeLeft();
    }
    
    @IBOutlet weak var btnDismiss: UIButton!
    @IBOutlet weak var tableviews: UITableView!
    
     var nameArray = [String]()
    var imgArray = [String]()
    var mainViewController: UIViewController!
    var habitOrderings: UIViewController!
    var pointsFrequency: UIViewController!
    var summaries: UIViewController!
    var referFriends: UIViewController!
    var setting: UIViewController!
    var todaySpecial: UIViewController!
    var logoutScreen: UIViewController!
    
    var profileImage:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
      nameArray = ["Add Habits","Habits and Ordering","Points and Summary ","Refer and Invite Friends","Settings","Today's Special","Logout"]
        imgArray = ["add_Habits","habits_Order","ponts_Frequency","refer_Freinds","settings","todaySpecial","logout"]
        
        let addHabits = self.storyboard?.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
        self.mainViewController = UINavigationController(rootViewController: addHabits)
        
        
        let habitOrder = self.storyboard?.instantiateViewController(withIdentifier: "HabitsOrderViewController")as! HabitsOrderViewController
        self.habitOrderings = UINavigationController(rootViewController: habitOrder)
    
        let h_Summary = self.storyboard?.instantiateViewController(withIdentifier: "SummaryViewController")as! SummaryViewController
        self.summaries = UINavigationController(rootViewController: h_Summary)
       
        let referFriends = self.storyboard?.instantiateViewController(withIdentifier: "ReferFreindsViewController")as! ReferFreindsViewController
        self.referFriends = UINavigationController(rootViewController: referFriends)
        
        let h_Settings = self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController")as! SettingsViewController
        self.setting = UINavigationController(rootViewController: h_Settings)
        
        let todaySpecial = self.storyboard?.instantiateViewController(withIdentifier: "TodaySpecialViewController")as! TodaySpecialViewController
        self.todaySpecial = UINavigationController(rootViewController: todaySpecial)
        
        
        
        let h_Logout = self.storyboard?.instantiateViewController(withIdentifier: "SignInViewController")as! SignInViewController
        
        
        self.logoutScreen = UINavigationController(rootViewController: h_Logout)
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.imageView.layer.cornerRadius = self.imageView.frame.size.width / 2
        self.imageView.layer.borderColor = UIColor.black.cgColor
        self.imageView.layer.borderWidth = 0.5
        self.imageView.clipsToBounds = true
        self.imageView.contentMode = .scaleToFill
        
        lblProfilename.text = UserDefaults.standard.value(forKey: "userName") as? String
       
        //self.imageView.sd_setImage(with: URL(string: UserDefaults.standard.value(forKey: "profileImage") as! String ), placeholderImage: UIImage(named: "logoImage"))
        getProfileCall()
    }
   func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    // UITableview Datasource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return nameArray.count
    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 60
//    }
    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

    
     let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! CustomCell
    cell.lbl_Menu.text = nameArray[indexPath.row]
    let imageName = imgArray[indexPath.row]
      cell.img_Menu.image = UIImage(named: imageName)!
    
    
    return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("tapped",indexPath.row)
        if let menu = LeftMenu(rawValue: indexPath.row) {
            self.changeViewController(menu)
        }
        
    }
    

    func changeViewController(_ menu: LeftMenu) {
        switch menu {
        case .main:
            self.slideMenuController()?.changeMainViewController(self.mainViewController, close: true)
        case .H_Order:
            self.slideMenuController()?.changeMainViewController(self.habitOrderings, close: true)
        
        case .summrie:
            self.slideMenuController()?.changeMainViewController(self.summaries, close: true)
        case .referFriend:
            self.slideMenuController()?.changeMainViewController(self.referFriends, close: true)
        case .setting:
            self.slideMenuController()?.changeMainViewController(self.setting, close: true)
        case .special:
            self.slideMenuController()?.changeMainViewController(self.todaySpecial, close: true)
        case .exit:
            
            popupAlert(title: "Logout", message: "Do you want to logout app ?", actionTitles: ["Yes","No"], actions: [{ (action1) in
                GIDSignIn.sharedInstance().signOut()

                UserDefaults.standard.set(false, forKey: "mainController")
                self.slideMenuController()?.changeMainViewController(self.logoutScreen, close: true)
                },{(action2) in

                }])
           
        }
    }
    
    func getProfileCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.profile_Details)
        
        let parameters = ["id":UserDefaults.standard.value(forKey: "userID")!]
        
        requestPOSTURL(url, params: parameters as [String : AnyObject], success: { (data) in
            print(data)
            self.profileImage = data["profile_image"].stringValue
             self.imageView.sd_setImage(with: URL(string: self.profileImage! ), placeholderImage: UIImage(named: "logoImage"))
           
        }) { (error) in
            print(error)
        }
    }

}
