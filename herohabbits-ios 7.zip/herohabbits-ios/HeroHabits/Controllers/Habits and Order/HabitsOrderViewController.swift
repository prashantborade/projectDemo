//
//  ViewController.swift
//  HeroHabits
//
//  Created by aspl on 25/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import SlideMenuControllerSwift

class HabitsOrderViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var imgOrderArray = [String]()
    var titleArray = [String]()
    var categoryArray = [String]()
    var dragInitialIndexPath: IndexPath?
    var dragCellSnapshot: UIView?
    var habitTitle,habitIcon,habitID,subCategory,deleteID,hSequneceId:String?
    var takeStrKey:String?
    
    var titleDataSet = [String]()
    var iconDataSet = [String]()
    var habitIdDataSet = [String]()
    var subCategoryDataset = [String]()
    var sequenceDataSet = [String]()
    var setDictionary = [String:Int]()
    var setdict:NSDictionary!
    var myArray = Array<AnyObject>()
    var dict = Dictionary<String, AnyObject>()
    var newOrderArray = [[String]]()
    var mutableArray:NSMutableArray = []
    var setSummaryFlag:String?
    
    var OrderDataSet = [HabitOrder]()
    var totalOrderDataSet = [HabitOrder]()
   
    @IBOutlet weak var tableView: UITableView!
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //navigationController?.navigationBar.isHidden = true
        navigationController?.navigationBar.barTintColor = UIColor.black
        navigationController?.navigationBar.tintColor = UIColor.white
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.white]
        view.backgroundColor = UIColor.white
        title = "Habits and Ordering"
        
        imgOrderArray = ["workout_One","reading","headphone","workout_Two","yoga"]
        titleArray = ["High intensity workout","Read bible","Read or audioble for 20 mins","Take the stairs","Meditation"]
        categoryArray = ["Workout","Reading","Food","Workout","Meditation"]
        
       // self.tableView.isEditing = true
        
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(onLongPressGesture(sender:)))
        longPress.minimumPressDuration = 0.2 // optional
        tableView.addGestureRecognizer(longPress)
//       navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Add", style: .plain, target: self, action: #selector(addTapped))

        //getAllHabit()
    }
    
//    @objc func addTapped(sender: UIBarButtonItem){
//        print("success")
//       habitOrderCall()
//    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
        getAllHabit()
    }
    
    @objc func onLongPressGesture(sender: UILongPressGestureRecognizer) {
        let locationInView = sender.location(in: tableView)
        let indexPath = tableView.indexPathForRow(at: locationInView)
        
        if sender.state == .began {
            if indexPath != nil {
                dragInitialIndexPath = indexPath
                let cell = tableView.cellForRow(at: indexPath!)
                dragCellSnapshot = snapshotOfCell(inputView: cell!)
                var center = cell?.center
                dragCellSnapshot?.center = center!
                dragCellSnapshot?.alpha = 0.0
                tableView.addSubview(dragCellSnapshot!)
                
                UIView.animate(withDuration: 0.25, animations: { () -> Void in
                    center?.y = locationInView.y
                    self.dragCellSnapshot?.center = center!
                    self.dragCellSnapshot?.transform = (self.dragCellSnapshot?.transform.scaledBy(x: 1.05, y: 1.05))!
                    self.dragCellSnapshot?.alpha = 0.99
                    cell?.alpha = 0.0
                }, completion: { (finished) -> Void in
                    if finished {
                        cell?.isHidden = false
                    }
                })
            }
        } else if sender.state == .changed && dragInitialIndexPath != nil {
            var center = dragCellSnapshot?.center
            center?.y = locationInView.y
            dragCellSnapshot?.center = center!
            
            // to lock dragging to same section add: "&& indexPath?.section == dragInitialIndexPath?.section" to the if below
            if indexPath != nil && indexPath != dragInitialIndexPath {
                // update your data model
//                let dataToMove = sequenceDataSet[dragInitialIndexPath!.row]
//                sequenceDataSet.remove(at: dragInitialIndexPath!.row)
//                sequenceDataSet.insert(dataToMove, at: indexPath!.row)
                
                let moveHabitID = habitIdDataSet[dragInitialIndexPath!.row]
                habitIdDataSet.remove(at: dragInitialIndexPath!.row)
                habitIdDataSet.insert(moveHabitID, at: indexPath!.row)
                
             
//                OrderDataSet.remove(at: dragInitialIndexPath!.row)
//                OrderDataSet.insert(dataToMove, at: indexPath!.row)
                
                tableView.moveRow(at: dragInitialIndexPath!, to: indexPath!)
               // print("titledataset",OrderDataSet[(indexPath?.row)!].hSequenceId)
                 habitOrderCall()
                print("sequenceDataSet = >",sequenceDataSet)
                print("habitIdDataSet = >",habitIdDataSet)
               
   //       print("setDictionary = ",myArray)
                dragInitialIndexPath = indexPath
            }
        } else if sender.state == .ended && dragInitialIndexPath != nil {
            let cell = tableView.cellForRow(at: dragInitialIndexPath!)
            cell?.isHidden = false
            cell?.alpha = 0.0
            UIView.animate(withDuration: 0.25, animations: { () -> Void in
                self.dragCellSnapshot?.center = (cell?.center)!
                self.dragCellSnapshot?.transform = CGAffineTransform.identity
                self.dragCellSnapshot?.alpha = 0.0
                cell?.alpha = 1.0
            }, completion: { (finished) -> Void in
                if finished {
                    self.dragInitialIndexPath = nil
                    //self.dragCellSnapshot?.removeFromSuperview()
                    self.dragCellSnapshot = nil
                }
            })
        }
    }
        
    func snapshotOfCell(inputView: UIView) -> UIView {
        UIGraphicsBeginImageContextWithOptions(inputView.bounds.size, false, 0.0)
        inputView.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        let cellSnapshot = UIImageView(image: image)
        cellSnapshot.layer.masksToBounds = false
        cellSnapshot.layer.cornerRadius = 0.0
        cellSnapshot.layer.shadowOffset = CGSize(width: -5.0, height: 0.0)
        cellSnapshot.layer.shadowRadius = 5.0
        cellSnapshot.layer.shadowOpacity = 0.4
        return cellSnapshot
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    // UITableview Datasource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return titleDataSet.count
    }
    
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 80
        }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! OrderList
//        let imgName = titleDataSet[indexPath.row]
//        cell.img_Order.image = UIImage(named: imgName)
        cell.lblTitle.text = titleDataSet[indexPath.row]
        cell.lblCategory.text = subCategoryDataset[indexPath.row]
        cell.img_Order.sd_setImage(with: URL(string: iconDataSet[indexPath.row]), placeholderImage: UIImage(named: "logoImage"))
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("tapped",indexPath.row)
        setSummaryFlag = "OrderHabit"
        UserDefaults.standard.set(setSummaryFlag!, forKey: "SummaryFlag")
       // let habit_ID = totalOrderDataSet[indexPath.row].hOrderId
        let habit_ID = habitIdDataSet[indexPath.row]
        let title = titleDataSet[indexPath.row]
        UserDefaults.standard.set(habit_ID, forKey: "habit_ID")
        let controller = storyboard?.instantiateViewController(withIdentifier: "DetailsScreenVC") as! DetailsScreenVC
        controller.getHabitTitle = title
        
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        
        
        let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
            self.deleteID = self.habitIdDataSet[indexPath.row]
            print(self.deleteID!)
            
           self.deleteCall()
            //            self.titleCategoryArray.remove(at: indexPath.row)
            //            self.imgCategoryArray.remove(at: indexPath.row)
            // self.categoryTableView.reloadData()
        })
        
        return [deleteAction]
    }
    func getAllHabit(){
        var url = webConstant.baseUrl
        url.append(webConstant.allHabit_list)
        let parms = ["user_id":UserDefaults.standard.value(forKey: "userID")!]
        print(parms)
        requestGETURL(url, params:parms as [String : AnyObject]  , success: { (data) in
            print(data)
            let status = data["status"].boolValue
            var dataIterator = 0
            if !status{
                
            }else{
                
                self.iconDataSet.removeAll()
                self.titleDataSet.removeAll()
                self.habitIdDataSet.removeAll()
                self.sequenceDataSet.removeAll()
                self.subCategoryDataset.removeAll()
//                self.totalOrderDataSet.removeAll()
//                self.OrderDataSet.removeAll()
                for habitList in data["resultdata"].arrayValue{
                    
                    self.habitTitle = habitList["title"].stringValue
                    self.habitIcon = habitList["icon"].stringValue
                    self.habitID = habitList["habit_id"].stringValue
                    self.subCategory = habitList["category"].stringValue
                    self.hSequneceId = habitList["sequence_no"].stringValue
                    
//                    self.OrderDataSet.append(HabitOrder(tittle: self.habitTitle!, image: self.habitIcon!, subCategory: self.subCategory!, orderId: self.habitID!, sequenceID: self.hSequneceId!))
//
//                    self.totalOrderDataSet = self.OrderDataSet
                    
                    self.titleDataSet.append(self.habitTitle!)
                    self.iconDataSet.append(self.habitIcon!)
                    self.habitIdDataSet.append(self.habitID!)
                    self.subCategoryDataset.append(self.subCategory!)
                    self.sequenceDataSet.append(self.hSequneceId!)
                    
                    dataIterator = dataIterator + 1
                    
                }
                self.tableView.reloadData()
            }
        }) { (error) in
            print(error)
        }
    }
    
    func deleteCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.delete_habit)
        let parms = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"habit_id":deleteID!]
        print(parms)
        requestGETURL(url, params:parms as [String : AnyObject]  , success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    self.getAllHabit()
                    }])
            }else{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    self.getAllHabit()
                    }])
                
            }
        }) { (error) in
            print(error)
        }
    }
    
    func habitOrderCall(){
        
       // let sequenceData = sequenceDataSet.map { Int($0)!}
        // setDictionary.removeAll()
//        for i in 0..<habitIdDataSet.count{
//            let id=habitIdDataSet[i]
//            let value0 = sequenceData[i]
//            setDictionary[id] = value0
//            //setDictionary.updateValue(value0, forKey: id)
//
//        }
        
        let sequenceData = sequenceDataSet.map { Int($0)!}
        print(sequenceData)
        for (index,value) in habitIdDataSet.enumerated()
        {
            print("key",sequenceData[index])
            print("value",value)

            setDictionary.updateValue(sequenceData[index], forKey: value)

        }
//
        print("set dict ",setDictionary)
        
       
        
        let jsonData = try! JSONSerialization.data(withJSONObject: setDictionary, options: JSONSerialization.WritingOptions.prettyPrinted)

        let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
        print(jsonString)

        var url = webConstant.baseUrl
        url.append(webConstant.update_sequence_no)

        let params = ["habit_list": jsonString,"user_id":UserDefaults.standard.value(forKey: "userID")!]

        print(params)

        requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
            print("data = >",data)
        }) { (error) in
            print(error)
        }
    }
    
}


class HabitOrder{
    let hOrderId:String
    let hOrderImage:String
    let hOrderTitle:String
    let hOrderSubCategory:String
    let hSequenceId:String
    
    init(tittle:String,image:String,subCategory:String,orderId:String,sequenceID:String) {
        self.hOrderTitle = tittle
        self.hOrderImage = image
        self.hOrderId = orderId
        self.hOrderSubCategory = subCategory
        self.hSequenceId = sequenceID
    }
}
