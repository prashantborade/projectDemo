//
//  ReferFreindsViewController.swift
//  HeroHabits
//
//  Created by aspl on 31/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class ReferFreindsViewController: UIViewController {

    @IBOutlet weak var txtInviteView: UITextView!
    
    var App_Link : String = ""
    override func viewDidLoad() {
        super.viewDidLoad()

//        navigationController?.navigationBar.barTintColor = UIColor.black
//        navigationController?.navigationBar.tintColor = UIColor.white
//        navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.white]
//        view.backgroundColor = UIColor.white
        setNavigate()
     //   title = "Invite Friends"
        inviteCall()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
        
    }
    
    @IBAction func btnInviteTapped(_ sender: Any) {
        self.App_Link = "google.com"
        let text = self.App_Link
        
        // set up activity view controller
        let textToShare = [ text ]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
        activityViewController.popoverPresentationController?.sourceRect = CGRect(x: view.center.x, y: view.center.y, width: 0, height: 0)
       
        activityViewController.popoverPresentationController?.permittedArrowDirections = UIPopoverArrowDirection(rawValue: 0)
        // present the view controller
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    func inviteCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.invite_others)
        
        requestGETURL(url, params: nil, success: { (data) in
            print(data)
            let status = data["status"].boolValue
            if !status{
                
            }else{
                let content = data["resultdata"]["content"].stringValue
                self.txtInviteView.text = content
                self.title = data["resultdata"]["title"].stringValue
            }
        }) { (error) in
            print(error)
        }
    }
    

}
