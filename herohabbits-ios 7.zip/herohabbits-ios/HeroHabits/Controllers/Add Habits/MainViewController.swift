//
//  MainViewController.swift
//  HeroHabits
//
//  Created by aspl on 25/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import SlideMenuControllerSwift

enum Weekday: String {
    case Monday  = "Monday"
    case Tuesday = "Tuesday"
    case Wednesday   = "Wednesday"
    case Thursday  = "Thursday"
    case Friday = "Friday"
    case Satuarday = "Satuarday"
    case Sunday = "Sunday"
    // ... and so on ...
}
class MainViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    
    @IBOutlet weak var mainTableView: UITableView!
    var hero : [String] = []
    var selected : Bool = true
    var habitArray = [Habits]()
    var selectedArray = [String]()
    var currentHabitArray = [Habits]()
    var habitTitle,habitID,habitIcon,subCategory,editID,trackerID:String?
    var titleDataSet = [Habit]()
    var totalDataset = [Habit]()
    var iconDataSet = [String]()
    var habitIdDataSet = [String]()
    var subCategoryDataset = [String]()
    var selectHabitID:String?
    var statusID:Int = 0
    var setIndex:String?
    var setFlag:String?
    var setSummaryFlag:String?
    var currentDay:String?
    var todays = ""
    var params = [String:AnyObject]()
    var refreshControl = UIRefreshControl()
    var getTodayList:String?
    var theLabel: UILabel = {
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
        label.text = "No Habit schedule"
         return label
    }()
    
    @IBOutlet weak var btnSundayOutlet: UIButton!
    @IBOutlet weak var btnMondayOutlet: UIButton!
    @IBOutlet weak var btnTuesdayOutlet: UIButton!
    @IBOutlet weak var btnWensdayOutlet: UIButton!
    @IBOutlet weak var btnThursdayOutlet: UIButton!
    @IBOutlet weak var btnFridayOutlet: UIButton!
    @IBOutlet weak var btnSaturdayOutlet: UIButton!
    
    @IBOutlet weak var daysView: UIView!
    
    override func viewDidLayoutSubviews() {
        /* Set the frame when the layout is changed */
        theLabel.center = CGPoint(x: self.view.frame.size.width / 2, y: self.view.frame.size.height / 2)
        theLabel.textAlignment = .center
    }
    override func viewDidLoad() {
        super.viewDidLoad()
         self.mainTableView.contentInset = UIEdgeInsets(top: -35, left: 0, bottom: 0, right: 0)
       //  getHabitListCall()
      // currentHabitArray = ["1","2","3","4","5","6","7","1","2","3","4","5","6","7"]
        habitArray.append(Habits(name: "High intensity workout ", subname: "Workout", image: "icon3"))
        habitArray.append(Habits(name: "Isagenix ( 2 shakes & 2 snacks ) ", subname: "Food", image: "icon4"))
        habitArray.append(Habits(name: "Take the stairs ", subname: "Workout", image: "icon35"))
        currentHabitArray = habitArray
      let userID = UserDefaults.standard.value(forKey: "userID")
        print("userID = \(userID!)")
        
        
        let date = Date()
        print(date.dayOfWeek()!)
        setWeekdayinSting(today: date.dayOfWeek()!)
        
       
        
        for _ in currentHabitArray {
            
            let idex = "0"
            self.selectedArray.append(idex)
        }
        for _ in totalDataset {
            
            let idex = "0"
            self.selectedArray.append(idex)
        }
        
        setNavigate()
        title = "Hero Habits"
       
       
        
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")

        refreshControl.addTarget(self, action: #selector(MainViewController.refresh(sender:)), for: UIControlEvents.valueChanged)
        mainTableView.addSubview(refreshControl)
        
    }
    @objc func refresh(sender:AnyObject) {
       getHabitListCall()
        refreshControl.endRefreshing()
    }
    
    @IBAction func btnAddHabitClicked(_ sender: Any) {
        currentDay = ""
        title = "Hero Habits"
        let controller = storyboard?.instantiateViewController(withIdentifier: "CategoryListVC") as! CategoryListVC
          self.navigationController?.pushViewController(controller, animated: true)
        
        
    }
    func setWeekdayinSting(today: String)
    {
        switch today {
        case Weekday.Monday.rawValue:
            title = "Today"
            self.btnMondayOutlet.setImage(UIImage(named: "m_selected"), for: .normal)
            break
        case Weekday.Tuesday.rawValue:
            title = "Today"
             self.btnTuesdayOutlet.setImage(UIImage(named: "t_selected"), for: .normal)
            break
        case Weekday.Wednesday.rawValue:
            title = "Today"
             self.btnWensdayOutlet.setImage(UIImage(named: "w_selected"), for: .normal)
            break
        case Weekday.Thursday.rawValue:
            title = "Today"
            self.btnThursdayOutlet.setImage(UIImage(named: "t_selected"), for: .normal)
            break
        case Weekday.Friday.rawValue:
            title = "Today"
            self.btnFridayOutlet.setImage(UIImage(named: "f_selected"), for: .normal)
            break
        case Weekday.Satuarday.rawValue:
           title = "Today"
            self.btnSaturdayOutlet.setImage(UIImage(named: "s_selected"), for: .normal)
            break
        case Weekday.Sunday.rawValue:
           title = "Today"
            self.btnSundayOutlet.setImage(UIImage(named: "s_selected"), for: .normal)
            break
        default:
            
            break
        }
        
    }
 
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       

            self.setNavigationBarItem()
            getHabitListCall()
            self.mainTableView.reloadData()
      
       
    }
    
    // UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return totalDataset.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        
        
        let userCellID = "MainCustomCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: userCellID, for: indexPath) as! MainCustomCell
        cell.lblTitle.text = totalDataset[indexPath.row].habitTitle
        cell.lblSubTitle.text = totalDataset[indexPath.row].habitSubname
       // cell.imgView.image = UIImage(named: iconDataSet[indexPath.row])
       
     // cell.imgView.sd_setImage(with: URL(string: totalDataset[indexPath.row].habitImage), placeholderImage: UIImage(named: "logoImage"))
        
        
        if totalDataset[indexPath.row].editId == "1"{
            cell.lblTitle.textColor = UIColor.gray
            cell.lblSubTitle.textColor = UIColor.gray
//            cell.lblSubTitle.text = totalDataset[indexPath.row].habitSubname + " ( " + "\(UserDefaults.standard.value(forKey: "tracked") as? String ?? "Tracked")" + " )"
           cell.lblSubTitle.text = totalDataset[indexPath.row].habitSubname + " ( " + "Tracked" + " )"
            selected = false
            DispatchQueue.main.async {
                
            
            do {
                let url:URL = URL(string: self.totalDataset[indexPath.row].habitImage )!
                let data = try Data(contentsOf: url)
                let images = UIImage(data: data)
                let currentCGImage = images?.cgImage
                let currentCIImage = CIImage(cgImage: currentCGImage!)

                let filter = CIFilter(name: "CIColorMonochrome")
                filter?.setValue(currentCIImage, forKey: "inputImage")

                // set a gray value for the tint color
                filter?.setValue(CIColor(red: 0.7, green: 0.7, blue: 0.7), forKey: "inputColor")

                filter?.setValue(1.0, forKey: "inputIntensity")
                let outputImage = filter?.outputImage

                let context = CIContext()

                if let cgimg = context.createCGImage(outputImage!, from: (outputImage?.extent)!) {
                    let processedImage = UIImage(cgImage: cgimg)
                    cell.imgView.image = processedImage
                }
            }
            catch{
                print(error)
            }

            }
            }else if totalDataset[indexPath.row].editId == "2"{

            cell.lblTitle.textColor = UIColor.gray
            cell.lblSubTitle.textColor = UIColor.gray
//             cell.lblSubTitle.text = totalDataset[indexPath.row].habitSubname + " ( " + "\(UserDefaults.standard.value(forKey: "tracked") as? String ?? "Rejected")" + " )"
            cell.lblSubTitle.text = totalDataset[indexPath.row].habitSubname + " ( " + "Missed" + " )"
            selected = false
            DispatchQueue.main.async {
            
            do {
                let url:URL = URL(string: self.totalDataset[indexPath.row].habitImage )!
                let data = try Data(contentsOf: url)
                let images = UIImage(data: data)
                let currentCGImage = images?.cgImage
                let currentCIImage = CIImage(cgImage: currentCGImage!)

                let filter = CIFilter(name: "CIColorMonochrome")
                filter?.setValue(currentCIImage, forKey: "inputImage")

                // set a gray value for the tint color
                filter?.setValue(CIColor(red: 0.7, green: 0.7, blue: 0.7), forKey: "inputColor")

                filter?.setValue(1.0, forKey: "inputIntensity")
                let outputImage = filter?.outputImage

                let context = CIContext()

                if let cgimg = context.createCGImage(outputImage!, from: (outputImage?.extent)!) {
                    let processedImage = UIImage(cgImage: cgimg)
                    cell.imgView.image = processedImage
                }
            }
            catch{
                print(error)
            }
            }
            
        }else{
            selected = true
            cell.lblTitle.textColor = UIColor.black
            cell.lblSubTitle.textColor = UIColor.gray
            cell.imgView.sd_setImage(with: URL(string: totalDataset[indexPath.row].habitImage), placeholderImage: UIImage(named: "logoImage"))
            
        }

//        if setIndex! == "1"{
//            cell.lblTitle.textColor = UIColor.green
//            cell.lblSubTitle.textColor = UIColor.green
//        }else{
//
//        }
//        if self.selectedArray[indexPath.row] == "1"
//        {
//
//           // cell.cellBackgroundView.backgroundColor = UIColor.gray
//            cell.lblTitle.textColor = UIColor.green
//            cell.lblSubTitle.textColor = UIColor.green
//
//        }
//        else
//        {
//           // cell.cellBackgroundView.backgroundColor = UIColor.clear
//            cell.lblTitle.textColor = UIColor.black
//            cell.lblSubTitle.textColor = UIColor.lightGray
//        }
        //configure cell
       
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if totalDataset[indexPath.row].editId == "1" || totalDataset[indexPath.row].editId == "2"{
            self.popupAlert(title: "Hero Habit", message:"Are you want to reset habit", actionTitles: ["Ok","Cancel"], actions:[{ (action1) in
                self.statusID = 0
                self.selectHabitID = self.totalDataset[indexPath.row].trackerID
                self.trackServiceCall()
                },{(action2) in
                    
                }])
            

        }else{
        
            setSummaryFlag = "TodayHabit"
            UserDefaults.standard.set(setSummaryFlag!, forKey: "SummaryFlag")
                    let habit_ID = totalDataset[indexPath.row].habitID
                    let title = totalDataset[indexPath.row].habitTitle
                    UserDefaults.standard.set(habit_ID, forKey: "habit_ID")
                    let controller = storyboard?.instantiateViewController(withIdentifier: "DetailsScreenVC") as! DetailsScreenVC
                    controller.getHabitTitle = title
                    self.navigationController?.pushViewController(controller, animated: true)
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var size = CGFloat()
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
             size = 55.0
            break
        case .pad:
           size = 70.0
             break
        case .unspecified:
            break
        case .tv:
          break
        case .carPlay:
            break
        }
        return size
    }
    //swipeTableView
    
   
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
       // let s = UserDefaults.standard.value(forKey: "yes") as! String
        
        if totalDataset[indexPath.row].editId == "1" || totalDataset[indexPath.row].editId == "2"{
            selected = false
            return false
        }else if todays == "Yes"{
            selected = true
             return true
        }else if todays == "No"{
            selected = false
            return false
        }else{
            selected = true
            return true
        }
        
        
        
       
    }
    @available(iOS 11.0, *)
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let important = importantAction(at: indexPath)
//        let cell = tableView.dequeueReusableCell(withIdentifier: "MainCustomCell", for: indexPath) as! MainCustomCell
//
//
//        cell.lblSubTitle.textColor = UIColor.red
        //cell.imgView.tintColor = UIColor.gray
      //  selected = false
        
       

        //let delete = deleteAction(at: indexPath)
        return UISwipeActionsConfiguration(actions: [important])
//        let config = UISwipeActionsConfiguration(actions: [important])
//
//        config.performsFirstActionWithFullSwipe = false
       // return config
        
    }
    
    @available(iOS 11.0, *)
    func importantAction(at indexPath: IndexPath) -> UIContextualAction
    {
        
        let action = UIContextualAction(style: .normal, title: nil) { (action, view, completion) in
           
//            self.selected = true
//
//            self.selectedArray.remove(at: indexPath.row)
//            self.selectedArray.insert("1", at: indexPath.row)
//
//
//            print(self.selectedArray)
           
            self.mainTableView.reloadData()
            completion(true)
            
            self.selectHabitID = self.totalDataset[indexPath.row].trackerID
            self.statusID = 1
            self.trackServiceCall()
        }
        
        action.image = #imageLiteral(resourceName: "done")
        action.backgroundColor = UIColor.green
        
        
        return action
    }
    @available(iOS 11.0, *)
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let delete = deleteAction(at: indexPath)
        return UISwipeActionsConfiguration(actions: [delete])
    }
    
    @available(iOS 11.0, *)
    func deleteAction(at indexPath: IndexPath) -> UIContextualAction
    {
        let action = UIContextualAction(style: .normal, title: nil) { (action, view, completion) in
          
//            self.selectedArray.remove(at: indexPath.row)
//            self.selectedArray.insert("0", at: indexPath.row)
//
//            print(self.selectedArray)
            self.mainTableView.reloadData()
            completion(true)
            
            self.selectHabitID = self.totalDataset[indexPath.row].trackerID
            self.statusID = 2
            self.trackServiceCall()
        }
        
        action.image = #imageLiteral(resourceName: "delete")
        action.backgroundColor = UIColor.orange
        
        return action
    }
    
    func trackServiceCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.update_habit)
        let parms = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"habit_id":selectHabitID!,"status":statusID]
        print("parms = >",parms)
        requestGETURL(url, params: parms as [String : AnyObject], success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    UserDefaults.standard.set(message, forKey: "tracked")
                    self.getHabitListCall()
//                    if message == "tracked"{
//                        UserDefaults.standard.set(message, forKey: "tracked")
//                        self.selected = false
//                        self.getHabitListCall()
//
//                    }else if message == "Habit is reset"{
//                        self.selected = true
//                        self.getHabitListCall()
//                    }else{
//                        UserDefaults.standard.set(message, forKey: "unTracked")
//                        self.selected = false
//                        self.getHabitListCall()
//                    }
                    }])
            }
            
        }) { (error) in
            print(error)
        }
    }
    
    fileprivate let formatter: DateFormatter = {
        let formatter = DateFormatter()
        
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    func getHabitListCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.habit_list)
        
        
            if currentDay == "sunday"{
                params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"day":currentDay!] as [String : AnyObject]
            }else if currentDay == "monday"{
                params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"day":currentDay!] as [String : AnyObject]
            }else if currentDay == "tuesday"{
                params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"day":currentDay!] as [String : AnyObject]
            }else if currentDay == "wednesday"{
                params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"day":currentDay!] as [String : AnyObject]
            }else if currentDay == "thursday"{
                params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"day":currentDay!] as [String : AnyObject]
            }else if currentDay == "friday"{
                params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"day":currentDay!] as [String : AnyObject]
            }else if currentDay == "saturday"{
                params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"day":currentDay!] as [String : AnyObject]
            }else{
                params = ["user_id":UserDefaults.standard.value(forKey: "userID")!] as [String : AnyObject]
            }
        
       
        
       // let parms = ["user_id":UserDefaults.standard.value(forKey: "userID")!]
       // print(parms)
        requestGETURL(url, params:params as [String : AnyObject]  , success: { (data) in
            print(data)
           
            let status = data["status"].boolValue
            
          
            var dataIterator = 0
            if !status{
                
            }else{
                let habitDate = data["habit_date"].stringValue
                print("sdghfggf = >",habitDate)
                let formatter = DateFormatter()
                // initially set the format based on your datepicker date / server String
                formatter.dateFormat = "yyyy-MM-dd"
                
                let myString = formatter.string(from: Date()) // string purpose I add here
                // convert your string to date
                let yourDate = formatter.date(from: myString)
                //then again set the date format whhich type of output you need
                formatter.dateFormat = "yyyy-MM-dd"
                // again convert your date to string
                let myStringafd = formatter.string(from: yourDate!)
                
                print(myStringafd)
                
                if habitDate <= myStringafd {
                    print("yes")
                    self.todays = "Yes"
                   // self.selected = true
                }else{
                    self.todays = "No"
                    print("no")
                   // self.selected = false
                }
                let dataResult = data["resultdata"].arrayValue
                if dataResult.isEmpty{
                    self.totalDataset.removeAll()
                    self.titleDataSet.removeAll()
                    self.view.addSubview(self.theLabel)

                }else{
                  self.theLabel.removeFromSuperview()
                        self.totalDataset.removeAll()
                        self.titleDataSet.removeAll()
                    for habitList in data["resultdata"].arrayValue{
                        
                        self.habitTitle = habitList["title"].stringValue
                        self.habitIcon = habitList["icon"].stringValue
                        self.habitID = habitList["habit_id"].stringValue
                        self.subCategory = habitList["category"].stringValue
                        self.editID = habitList["status"].stringValue
                        self.trackerID = habitList["tracker_id"].stringValue
                       
                        
                        self.titleDataSet.append(Habit(name: self.habitTitle!, subname: self.subCategory!, images: self.habitIcon!, habitId: self.habitID!, editID: self.editID!, trackerId: self.trackerID!))
                       
                        self.totalDataset = self.titleDataSet
                        //                self.titleDataSet.append(self.habitTitle!)
                        //                self.iconDataSet.append(self.habitIcon!)
                        //                self.habitIdDataSet.append(self.habitID!)
                        //                self.subCategoryDataset.append(self.subCategory!)
                        
                        dataIterator = dataIterator + 1
                        
                    }
                    
                    
                   
                    for _ in self.totalDataset{
                        let idx = "0"
                        self.selectedArray.append(idx)
                    }
                    
                }
           
               
            }
             self.mainTableView.reloadData()
        }) { (error) in
            print(error)
        }
    }
    
 //Mark - Action
    
    
    @IBAction func btnSundatTapped(_ sender: Any) {
        
        currentDay = "sunday"
        let date = Date()
        if date.dayOfWeek() == "Sunday"{
            setWeekdayinSting(today: date.dayOfWeek()!)
        }else{
            title = "Sunday"
        }
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let controller = storyboard.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
//        self.navigationController?.pushViewController(controller, animated: true)
        
       
       
        getHabitListCall()
    }
    
    @IBAction func btnMondayTapped(_ sender: Any) {
        currentDay = "monday"
        let date = Date()
        if date.dayOfWeek() == "Monday"{
            setWeekdayinSting(today: date.dayOfWeek()!)
        }else{
            title = "Monday"
        }
        
       
       
        getHabitListCall()
    }
    
    @IBAction func btnTuesdayTapped(_ sender: Any) {
        currentDay = "tuesday"
        let date = Date()
        if date.dayOfWeek() == "Tuesday"{
            setWeekdayinSting(today: date.dayOfWeek()!)
        }else{
            title = "Tuesday"
        }
        
       
        
        getHabitListCall()
    }
    
    @IBAction func btnWednesdayTapped(_ sender: Any) {
        currentDay = "wednesday"
        let date = Date()
        if date.dayOfWeek() == "Wednesday"{
            setWeekdayinSting(today: date.dayOfWeek()!)
        }else{
            title = "Wednesday"
        }
        
        
        
        getHabitListCall()
    }
    
    @IBAction func btnThursdayTapped(_ sender: Any) {
        currentDay = "thursday"
        let date = Date()
        if date.dayOfWeek() == "Thursday"{
           setWeekdayinSting(today: date.dayOfWeek()!)
        }else{
             title = "Thursday"
        }
        
        
        
        getHabitListCall()
    }
    
    @IBAction func btnFridayTapped(_ sender: Any) {
        currentDay = "friday"
        let date = Date()
        if date.dayOfWeek() == "Friday"{
            setWeekdayinSting(today: date.dayOfWeek()!)
        }else{
            title = "Friday"
        }
          
       
        
        getHabitListCall()
    }
    
    @IBAction func btnSaturdayTapped(_ sender: Any) {
        currentDay = "saturday"
        let date = Date()
        if date.dayOfWeek() == "Saturday"{
            setWeekdayinSting(today: date.dayOfWeek()!)
        }else{
            title = "Saturday"
        }
        
        
        
        getHabitListCall()
    }
}

extension Date {
    func dayOfWeek() -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        return dateFormatter.string(from: self).capitalized
        // or use capitalized(with: locale) if you want
    }
    func currentDate() -> String?{
       
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
         return dateFormatter.string(from: self)
    }
    
    func currentDateForMonth() -> String?{
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd"
        return dateFormatter.string(from: self)
    }
    
    
    
}
extension MainViewController : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
        print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
        print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
        print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
        print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
        print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
        print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
        print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
        print("SlideMenuControllerDelegate: rightDidClose")
    }
}

class Habits {
    
    let titleName: String
    let SubTitle: String
    let image: String
    
    init(name: String, subname: String, image: String) {
        
        self.titleName = name
        self.image = image
        self.SubTitle = subname
        
    }
    
}

class Habit {
    let habitTitle:String
    let habitImage:String
    let habitSubname:String
    let habitID:String
    let editId:String
    let trackerID:String
    init(name:String,subname:String,images:String,habitId:String,editID:String,trackerId:String) {
        self.habitTitle = name
        self.habitSubname = subname
        self.habitImage = images
        self.habitID = habitId
        self.editId = editID
        self.trackerID = trackerId
    }
}

