//
//  CategoryListVC.swift
//  HeroHabits
//
//  Created by aspl on 05/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class CategoryListVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var imgCategoryArray = [String]()
    var titleCategoryArray = [String]()
    var totalCategoryID = [String]()
    var totalIconID = [String]()
    var takeCategory:String?

    var iconArray = [String]()
    
    var array_main:NSMutableArray = [];
    var imageArray : [String] = [];
    
    var categoryid_Array : [String] = [];
    var category_titleArray : [String] = [];
    var categoryID = [String]()
   
    var selected_categoryid = ""
    var deleteID:String!
    
    var categoryDataSet = [Activity]()
    var totalCategoryDataSet = [Activity]()
    
    
    @IBOutlet weak var categoryTableView: UITableView!
    @IBOutlet weak var btnRightArrow: UIButton!
    @IBOutlet weak var txtMyOwn: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "My Goal"
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)

      
        categoryListCall()
        
        
        
    }

    @IBAction func btnRightArrow(_ sender: Any) {
        
        let controller = storyboard?.instantiateViewController(withIdentifier: "AddCategoryVC") as! AddCategoryVC
        self.navigationController?.pushViewController(controller, animated: true)
    

        
    }
    //MARK:- Tableview Delegate
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return self.totalCategoryDataSet.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CategoryCell
        
        let imagename =  self.totalCategoryDataSet[indexPath.row].activity_image
        cell.img_CategoryList.sd_setImage(with: URL(string: imagename), placeholderImage: UIImage(named: "logoImage"))
        cell.lblCategoryList.text = self.totalCategoryDataSet[indexPath.row].activity_title
        
//      cell.img_CategoryList.image = UIImage(named: imgCategoryArray[indexPath.row])
//        cell.lblCategoryList.text = titleCategoryArray[indexPath.row]
       
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let category_id = totalCategoryDataSet[indexPath.row].activity_id
        let categoryTitle = totalCategoryDataSet[indexPath.row].activity_title
        UserDefaults.standard.set(category_id, forKey: "category_id")
        print(category_id)
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "ActivityListVC") as! ActivityListVC
        controller.categorySelection = category_id
        controller.getCategoryTitle = categoryTitle
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        
        
        let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
            self.deleteID = self.totalCategoryID[indexPath.row]
            print(self.deleteID)
          
            self.deleteCall()
//            self.titleCategoryArray.remove(at: indexPath.row)
//            self.imgCategoryArray.remove(at: indexPath.row)
           // self.categoryTableView.reloadData()
        })
        
        return [deleteAction]
    }
    
    //MARK:- WebService call
    func categoryListCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.user_category_list)
        
        let parms = ["user_id":UserDefaults.standard.value(forKey: "userID")!]
        
        requestGETURL(url, params: parms as [String : AnyObject], success: { (data) in
            print(data)
            
            let status = data["status"].boolValue
            
            if !status{
                
            }else{
                self.categoryDataSet.removeAll()
                self.totalCategoryDataSet.removeAll()
                
                var dataIterator = 0
                for categoryList in data["resultdata"].arrayValue{
                    let categoryIconId = categoryList["category_icon_id"].stringValue
                    let categoryId = categoryList["category_id"].stringValue
                    let categoryImage = categoryList["category_image"].stringValue
                    let categoryTittle = categoryList["category_title"].stringValue
                    
                    self.categoryDataSet.append(Activity(iconID: categoryIconId, activityID: categoryId, image: categoryImage, tittle: categoryTittle))
                    
                    self.totalCategoryDataSet = self.categoryDataSet
                    
                    dataIterator = dataIterator + 1
                }
                self.categoryTableView.reloadData()
            }
        }) { (error) in
            print(error)
        }
    }
    
    func deleteCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.delete_category)
        let parms = ["user_id":UserDefaults.standard.value(forKey: "userID")! as AnyObject,
                     "category_id":deleteID! as AnyObject]
        print(parms)
        requestGETURL(url, params: parms, success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                   
                }])
            }else{
                self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                    //self.getWebserviceCall()
                    self.categoryListCall()
                }])
            }
            
        }) { (error) in
            print(error)
        }
    }
    
}


