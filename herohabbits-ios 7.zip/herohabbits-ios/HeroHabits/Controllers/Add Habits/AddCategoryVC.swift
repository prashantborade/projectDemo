//
//  AddCategoryVC.swift
//  HeroHabits
//
//  Created by aspl on 06/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class AddCategoryVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var txt_category_title: UITextField!
    
     var iconArray = [String]()
    
    var array_main:NSMutableArray = [];
    var imageArray : [String] = [];
    
    var categoryid_Array : [String] = [];
    var category_titleArray : [String] = [];
    var selected_categoryid = ""
    var icon,categoryID,categoryTitle: String?
    
    //MARK:-
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Add Goal"
        
        for index in 1...32 {
            
            print("icon\(index)!")
            
            self.iconArray.append(("icon\(index)"))
            
            DispatchQueue.main.async {
                
                //self.collectionView.reloadData()
            }
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //getWebserviceCall()
        getCategoryListCall()
    }
    
 
    
    //MARK:- Collection delegate
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1;
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var sizes:CGSize? = nil
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
          sizes = CGSize(width: (view.frame.size.width - 20) / 6, height: 40.0)
            break
            
        case .pad:
            sizes = CGSize(width: (view.frame.size.width - 20) / 8, height: 80.0)
            break
            
        case .unspecified: break
        // Uh, oh! What could it be?
        case .tv:
            break
        case .carPlay:
            break
        }
        
        return sizes!
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AddCategoryCell", for: indexPath) as! AddCategoryCell
        

        cell.imgView.contentMode = .scaleAspectFit
        let imagename =  self.imageArray[indexPath.row]

       print(imagename);
        cell.imgView.sd_setImage(with: URL(string: imagename), placeholderImage: UIImage(named: "logoImage"))
    
        
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
         print("category_title",[self.categoryid_Array[indexPath.row]])
        selected_categoryid = self.categoryid_Array[indexPath.row]
        
    }
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.5) {
            if let cell = collectionView.cellForItem(at: indexPath) as? AddCategoryCell {
                cell.imgView.transform = .init(scaleX: 0.95, y: 0.95)
                //cell.contentView.backgroundColor = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1)
            }
        }
    }
    
   func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.5) {
            if let cell = collectionView.cellForItem(at: indexPath) as? AddCategoryCell {
                cell.imgView.transform = .identity
                cell.contentView.backgroundColor = .clear
            }
        }
    }
    
    //MARK:- button action
    @IBAction func btnAddGoalClicked(_ sender: Any)
    {
        //        let controller = storyboard?.instantiateViewController(withIdentifier: "ActivityListVC") as! ActivityListVC
        //        self.navigationController?.pushViewController(controller, animated: true)
        
        if(selected_categoryid .isEmpty)
        {
            self.popupAlert(title: "Hero Habits", message: "select category firstly", actionTitles: ["Ok"], actions: [{ (action1) in
                
               
                
                },{(action2) in
                    
                }])
        }else  if (txt_category_title.text?.isEmpty)!
        {
            self.popupAlert(title: "Hero Habits", message: "Provide category title", actionTitles: ["Ok"], actions: [{ (action1) in
                
                
                
                },{(action2) in
                    
                }])
        }
        else{
            print("selected_categoryid",selected_categoryid)
            print("selected_categoryTitle",txt_category_title.text!)
            let user_id = UserDefaults.standard.value(forKey: "userID") as! String
            print("selected_categoryTitle",user_id)
         
            AddCatagoiesWebservice()
            
            
        }
    }
    //MARK:- Webservice call
    
    
    func AddCatagoiesWebservice(){
        
            var url = webConstant.baseUrl
            url.append(webConstant.add_category)
            print(url)
            let user_id = UserDefaults.standard.value(forKey: "userID") as! String
            print("user_id",user_id)
            let parameter = ["category_title":txt_category_title.text! ,"category_icon_id":selected_categoryid,"user_id":user_id] as [String : Any]
            
            requestPOSTURL(url, params: parameter as [String : AnyObject], success: { (data) in
                print(data)
                let status = data["status"].boolValue
                if !status{
                    
                }else{
                    let msg = data["message"].stringValue
                    self.popupAlert(title: "Hero Habits", message: msg, actionTitles: ["Ok"], actions: [{ (action1) in
                        
                        self.navigationController?.popViewController(animated: true)
                        
                        },{(action2) in
                            
                        }])
                }
            }) { (error) in
                print(error)
            }
            
    }
    
    func getCategoryListCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.categoryList)
        requestGETURL(url, params: nil, success: { (data) in
            print("data",data)
            let status = data["status"].stringValue
            if status == "true"{
                
                var dataIterator = 0
                for categoryList in data["resultdata"].arrayValue{
                    self.icon = categoryList["icon"].stringValue
                    self.categoryTitle = categoryList["title"].stringValue
                    self.categoryID = categoryList["category_id"].stringValue
                    
                     self.imageArray.insert(self.icon!, at: dataIterator)
                    self.categoryid_Array.insert(self.categoryID!, at: dataIterator)
                    self.category_titleArray.insert(self.categoryTitle!, at: dataIterator)
                    dataIterator = dataIterator + 1
                }
                
                self.collectionView.reloadData()
            }
        }) { (error) in
            print(error)
        }
    }
}
