//
//  ScheduleViewController.swift
//  HeroHabits
//
//  Created by aspl on 07/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import FSCalendar

enum ScheduleWeekday: String {
    case Monday  = "Monday"
    case Tuesday = "Tuesday"
    case Wednesday   = "Wednesday"
    case Thursday  = "Thursday"
    case Friday = "Friday"
    case Satuarday = "Satuarday"
    case Sunday = "Sunday"
    // ... and so on ...
}
class ScheduleViewController: UIViewController,FSCalendarDataSource, FSCalendarDelegate, FSCalendarDelegateAppearance,UITableViewDelegate,UITableViewDataSource
{
   
    
    @IBOutlet weak var btnWeekly: UIButton!
    @IBOutlet weak var btnMonthly: UIButton!
    
    @IBOutlet weak var btnOnetime: UIButton!
    
    @IBAction func btnOnetimeTapped(_ sender: Any) {
        
        if ((sender as! UIButton).isSelected)
        {
         //   btnOnetime.isSelected = false
            
        }
        else
        {
            lbl_oneTime.font = UIFont.boldSystemFont(ofSize: 16.0)
            lbl_weekly.font = UIFont.systemFont(ofSize: 16.0)
            lbl_monthly.font = UIFont.systemFont(ofSize: 16.0)
            
            btnMonthly.isSelected = false
             btnWeekly.isSelected = false
            btnOnetime.isSelected = true
            calender.allowsMultipleSelection = true
            self.calender.reloadData()
            print("tap working")
            habitType = "1"
            print(habitType)
            weeeklyView.isHidden = true
            calender.isHidden = false
            calenderMonths.isHidden = true
            oneTimeView.isHidden = true//false
            weeklyView.isHidden = true
            monthlyView.isHidden = true
        }
        
        
    }
    
    @IBAction func btnWeeklyTapped(_ sender: Any) {
        
        if ((sender as! UIButton).isSelected)
        {
         //   btnWeekly.isSelected = false
            
        }
        else
        {
            lbl_weekly.font = UIFont.boldSystemFont(ofSize: 16.0)
            lbl_oneTime.font = UIFont.systemFont(ofSize: 16.0)
            lbl_monthly.font = UIFont.systemFont(ofSize: 16.0)
            btnMonthly.isSelected = false
            btnOnetime.isSelected = false
             btnWeekly.isSelected = true
            print("tap working")
            habitType = "3"
            weeeklyView.isHidden = false
            calender.isHidden = true
            calenderMonths.isHidden = true
            weeklyView.isHidden = true//false
            oneTimeView.isHidden = true
            monthlyView.isHidden = true
        }
        
    }
    
    
    @IBAction func btnMonthlyTapped(_ sender: Any) {
        
        if ((sender as! UIButton).isSelected)
        {
          //  btnMonthly.isSelected = false
            
        }
        else
        {
            lbl_monthly.font = UIFont.boldSystemFont(ofSize: 16.0)
            lbl_oneTime.font = UIFont.systemFont(ofSize: 16.0)
            lbl_weekly.font = UIFont.systemFont(ofSize: 16.0)
            
            btnMonthly.isSelected = true
            btnOnetime.isSelected = false
            btnWeekly.isSelected = false
            calenderMonths.allowsMultipleSelection = true
            self.calender.reloadData()
            
            print("tap working")
            habitType = "2"
            weeeklyView.isHidden = true
            calender.isHidden = true
            calenderMonths.isHidden = false
            monthlyView.isHidden = true//false
            weeklyView.isHidden = true
            oneTimeView.isHidden = true
        }
        
       
    }
    
    @IBOutlet weak var btnTickmark: UIButton!    
    @IBOutlet weak var btnSaturday: UIButton!
    @IBOutlet weak var btnFriday: UIButton!
    @IBOutlet weak var btnThursday: UIButton!
    @IBOutlet weak var btnWednesday: UIButton!
    @IBOutlet weak var btnTuesday: UIButton!
    @IBOutlet weak var btnMonday: UIButton!
    @IBOutlet weak var btnSunday: UIButton!
    
    @IBOutlet weak var calender: FSCalendar!
    
    @IBOutlet weak var calenderMonths: FSCalendar!
    @IBOutlet weak var monthlyView: UIView!
    @IBOutlet weak var weeklyView: UIView!
    @IBOutlet weak var oneTimeView: UIView!
    @IBOutlet weak var lbl_oneTime: UILabel!
    @IBOutlet weak var lbl_weekly: UILabel!
    @IBOutlet weak var lbl_monthly: UILabel!
    @IBOutlet weak var weeeklyView: UIView!
    @IBOutlet weak var tableview: UITableView!
    var WeekArray = [String]()
    var isSelectAllSelected : Bool = false
    var selectedCells = [String]()
    var selectDateCount = [String]()
    var selectMonthDateCount = [String]()
    var dateCount = [String:String]()
    var heroHabit = "2"
    var habitType = ""
    var params = [String:AnyObject]()
    var weekday = ""
    var selectWeekdays = [String]()
    var weekNumberArray = [String]()
    var todayListFlag:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
       title = "Schedule"
//        let date = Date()
//        print(date.dayOfWeek()!)
//
//        setWeekdayinSting(today: date.dayOfWeek()!)
       
      
        
       
        // Do any additional setup after loading the view.
        self.tableview.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        WeekArray = ["1st Week","2nd Week","3rd Week","4th Week"]
        weekNumberArray = ["1","2","3","4"]
        selectedCells = ["1","2","3","4"]
        let tapOneTime = UITapGestureRecognizer(target: self, action: #selector(oneTimeClicked))
        lbl_oneTime.isUserInteractionEnabled = true
        lbl_oneTime.addGestureRecognizer(tapOneTime)

        let tapWeekly = UITapGestureRecognizer(target: self, action: #selector(weeklyClicked))
        lbl_weekly.isUserInteractionEnabled = true
        lbl_weekly.addGestureRecognizer(tapWeekly)

        let tapMonthly = UITapGestureRecognizer(target: self, action: #selector(monthlyClicked))
        lbl_monthly.isUserInteractionEnabled = true
        lbl_monthly.addGestureRecognizer(tapMonthly)
        
        lbl_weekly.font = UIFont.boldSystemFont(ofSize: 16.0)
        
        btnMonthly.isSelected = false
        btnWeekly.isSelected = true
        btnOnetime.isSelected = false
        oneTimeView.isHidden = true
        weeklyView.isHidden = true
        monthlyView.isHidden = true
        calender.isHidden = false
        calenderMonths.isHidden = true
        habitType = "3"
       
    }
    
    
    @objc func oneTimeClicked() {
        
        lbl_oneTime.font = UIFont.boldSystemFont(ofSize: 16.0)
        lbl_weekly.font = UIFont.systemFont(ofSize: 16.0)
        lbl_monthly.font = UIFont.systemFont(ofSize: 16.0)
        
        btnMonthly.isSelected = false
        btnWeekly.isSelected = false
        btnOnetime.isSelected = true
        
         calender.allowsMultipleSelection = true
        self.calender.reloadData()
        print("tap working")
        habitType = "1"
        print(habitType)
         weeeklyView.isHidden = true
        calender.isHidden = false
         calenderMonths.isHidden = true
        oneTimeView.isHidden = true //false
        weeklyView.isHidden = true
        monthlyView.isHidden = true
    
    }
    
    @objc func weeklyClicked() {
        lbl_weekly.font = UIFont.boldSystemFont(ofSize: 16.0)
        lbl_oneTime.font = UIFont.systemFont(ofSize: 16.0)
        lbl_monthly.font = UIFont.systemFont(ofSize: 16.0)
        btnMonthly.isSelected = false
        btnOnetime.isSelected = false
        btnWeekly.isSelected = true
        
        print("tap working")
        habitType = "3"
        weeeklyView.isHidden = false
        calender.isHidden = true
        calenderMonths.isHidden = true
        weeklyView.isHidden = true//false
        oneTimeView.isHidden = true
        monthlyView.isHidden = true
        
        
    }
    
    @objc func monthlyClicked() {
        
        lbl_monthly.font = UIFont.boldSystemFont(ofSize: 16.0)
        lbl_oneTime.font = UIFont.systemFont(ofSize: 16.0)
        lbl_weekly.font = UIFont.systemFont(ofSize: 16.0)
        
        btnMonthly.isSelected = true
        btnOnetime.isSelected = false
        btnWeekly.isSelected = false
         calenderMonths.allowsMultipleSelection = true
        self.calender.reloadData()
       
        print("tap working")
        habitType = "2"
        weeeklyView.isHidden = true
        calender.isHidden = true
        calenderMonths.isHidden = false
        monthlyView.isHidden = true//false
        weeklyView.isHidden = true
        oneTimeView.isHidden = true
       
    }
  
    @IBAction func btnTickmarkClicked(_ sender: Any) {
        
        if ((sender as! UIButton).isSelected)
        {
            btnTickmark.isSelected = false
            heroHabit = "2"
            print(heroHabit)
        }
        else
        {
            btnTickmark.isSelected = true
            heroHabit = "1"
            print(heroHabit)
        }
    }
    
    
    @IBAction func btnScheduleClicked(_ sender: Any) {
        
        if habitType == ""{
            self.popupAlert(title: "Hero Habit", message: "Please Select Habit Type", actionTitles: ["Ok"], actions:[{ (action1) in
             
                }])
            
        }else if habitType == "1"{
            if selectDateCount.isEmpty{
                self.popupAlert(title: "Hero Habit", message: "Please Select dates", actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else{
               
                serviceCall()
            }
        }else if habitType == "3"{
            if selectedCells.isEmpty{
                self.popupAlert(title: "Hero Habit", message: "Please Select Weeks", actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else if selectWeekdays.isEmpty{
                self.popupAlert(title: "Hero Habit", message: "Please Select days", actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else{
                print("success",selectWeekdays)
                serviceCall()
            }
            
        }else if habitType == "2"{
            if selectMonthDateCount.isEmpty{
                self.popupAlert(title: "Hero Habit", message: "Please Select dates", actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else{
                serviceCall()
            }
        }
        
        
    }
    
    fileprivate let formatter: DateFormatter = {
        let formatter = DateFormatter()
        
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    fileprivate let formatterForMonthly: DateFormatter = {
        let formatterForMonthly = DateFormatter()
        
        formatterForMonthly.dateFormat = "dd"
        return formatterForMonthly
    }()
    // MARK: - Calender Delegate
    
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
       
        print("did select date \(self.formatter.string(from: date))")
        print("did select date \(self.formatterForMonthly.string(from: date))")
     
        if habitType == "1"{
            self.selectDateCount.append(self.formatter.string(from: date))
            print("selectDateCount",selectDateCount)
            print("dateCount",dateCount)
        }else{
            self.selectMonthDateCount.append(self.formatterForMonthly.string(from: date))
            print("selectDateCount",selectMonthDateCount)
            print("dateCount",dateCount)
        }
        
    }
    
    func calendar(_ calendar: FSCalendar, didDeselect date: Date) {
        print("did deselect date \(self.formatter.string(from: date))")
        print("did select date \(self.formatterForMonthly.string(from: date))")
        if habitType == "1"{
            while selectDateCount.contains(self.formatter.string(from: date)) {
                if let itemToRemoveIndex = selectDateCount.index(of: self.formatter.string(from: date)) {
                    selectDateCount.remove(at: itemToRemoveIndex)
                }
            }
        }else{
            while selectMonthDateCount.contains(self.formatterForMonthly.string(from: date)) {
                if let itemToRemoveIndex = selectMonthDateCount.index(of: self.formatterForMonthly.string(from: date)) {
                    selectMonthDateCount.remove(at: itemToRemoveIndex)
                }
            }
        }
        
        print("selectDateCount_remove=>",selectDateCount)
    }
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at     monthPosition: FSCalendarMonthPosition) -> Bool{
        let divas = Date()
        if habitType == "1"{
        if self.formatter.string(from: date) < divas.currentDate()!{
            print("false")
            return false
        }else{
            print("true")
            return true
        }
        }else{
            if self.formatter.string(from: date) < divas.currentDate()!{
                print("false")
                return false
            }else{
                print("true")
                return true
            }
        }
       
        
       
    }
    
   
    
    func serviceCall(){
        for (index, value) in selectDateCount.enumerated(){
            let key = "date" + String(index + 1)
            self.dateCount.updateValue(value, forKey: key)
        }
        print(dateCount)
        let newArray:NSMutableArray = []
        
        let selectDatesCount = self.selectDateCount.count
        print(selectDatesCount)
        newArray.add(dateCount)
        print("newArray",newArray)
        let jsonData = try! JSONSerialization.data(withJSONObject: newArray, options: JSONSerialization.WritingOptions.prettyPrinted)
        
        let jsonString = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
        
        print("jsonString=>",jsonString)
        
        print("selectedCells = >",selectedCells.joined(separator: ","))
        
        
        if habitType == "1"{
            self.params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"category_id":UserDefaults.standard.value(forKey: "category_id")!,"activity_id":UserDefaults.standard.value(forKey: "activity_id")!,"habit_type":habitType,"my_hero_habit":heroHabit,"onetime_dates":jsonString,"dates_count":selectDatesCount,"monthly_dates":"","weeks":"","weekly_days":""] as [String : AnyObject]
        }else if habitType == "3"{
            self.params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"category_id":UserDefaults.standard.value(forKey: "category_id")!,"activity_id":UserDefaults.standard.value(forKey: "activity_id")!,"habit_type":habitType,"my_hero_habit":heroHabit,"onetime_dates":"","dates_count":"0","monthly_dates":"","weeks":selectedCells.joined(separator: ","),"weekly_days":selectWeekdays.joined(separator: ",")] as [String : AnyObject]
        }else{
            self.params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"category_id":UserDefaults.standard.value(forKey: "category_id")!,"activity_id":UserDefaults.standard.value(forKey: "activity_id")!,"habit_type":habitType,"my_hero_habit":heroHabit,"onetime_dates":"","dates_count":selectDatesCount,"monthly_dates":selectMonthDateCount.joined(separator: ","),"weeks":"","weekly_days":""] as [String : AnyObject]
        }
        
       
        print(params)
        
        var url = webConstant.baseUrl
        url.append(webConstant.add_habit)
        
        requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    let controller = self.navigationController?.viewControllers[0] as! MainViewController
                    
                self.navigationController!.popToViewController(controller, animated: true)
                    //self.navigationController?.popToRootViewController(animated: true)
                    
//                    let dashboardVC = self.navigationController!.viewControllers.filter { $0 is MainViewController }.first!
//
//                    self.navigationController!.popToViewController(dashboardVC, animated: true)
//                    for controller in self.navigationController!.viewControllers as Array {
//
//                        if controller.isKind(of: MainViewController.self) {
//
//                            self.navigationController!.popToViewController(controller, animated: true)
//                            break
//                        }
//                    }
                    }])
            }
        }) { (error) in
            print(error)
        }
    }
    //    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    //        return 60
    //    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return WeekArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell = (self.tableview.dequeueReusableCell(withIdentifier: "cell"))!
        
        cell.textLabel?.text = self.WeekArray[indexPath.row]

     //   cell.accessoryType = weekNumberArray[indexPath.row] ? .checkmark : .none
        cell.accessoryType = self.selectedCells.contains(weekNumberArray[indexPath.row]) ? .checkmark : .none
        

        return cell
        
        
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if self.selectedCells.contains(weekNumberArray[indexPath.row]) {
          
            self.selectedCells.remove(at: self.selectedCells.index(of: weekNumberArray[indexPath.row])!)
            print("remove",self.selectedCells)
        } else {
            
            self.selectedCells.append(weekNumberArray[indexPath.row] )
            print("add",self.selectedCells)
        }
        
        tableView.reloadData()

    }

    
    func setWeekdayinSting(today: String)
    {
        switch today {
        case ScheduleWeekday.Monday.rawValue:
            
            self.btnMonday.setImage(UIImage(named: "m_selected-1"), for: .normal)
            break
        case ScheduleWeekday.Tuesday.rawValue:
            self.btnTuesday.setImage(UIImage(named: "t_selected-1"), for: .normal)
            break
        case ScheduleWeekday.Wednesday.rawValue:
            self.btnWednesday.setImage(UIImage(named: "w_selected-1"), for: .normal)
            break
        case ScheduleWeekday.Thursday.rawValue:
            self.btnThursday.setImage(UIImage(named: "t_selected-1"), for: .normal)
            break
        case ScheduleWeekday.Friday.rawValue:
            self.btnFriday.setImage(UIImage(named: "f_selected-2"), for: .normal)
            break
        case ScheduleWeekday.Satuarday.rawValue:
            self.btnSaturday.setImage(UIImage(named: "s_selected-1"), for: .normal)
            break
        case ScheduleWeekday.Sunday.rawValue:
            self.btnSunday.setImage(UIImage(named: "s_selected-1"), for: .normal)
            break
        default:
            
            break
        }
        
    }
    
    
    @IBAction func btnAlldayTapped(_ sender: Any) {
        
        if ((sender as! UIButton).isSelected)
        {
            btnSunday.isSelected = false
           
            while selectWeekdays.contains("Sun") {
                if let itemToRemoveIndex = selectWeekdays.index(of: "Sun") {
                    selectWeekdays.remove(at: itemToRemoveIndex)
                }
            }
            
        }
        else
        {
            btnSunday.isSelected = true
           weekday = "Sun"
            self.selectWeekdays.append(weekday)
           
        }
    }
    
    @IBAction func btnMondayTapped(_ sender: Any) {
        if ((sender as! UIButton).isSelected)
        {
            btnMonday.isSelected = false
           
            while selectWeekdays.contains("Mon") {
                if let itemToRemoveIndex = selectWeekdays.index(of: "Mon") {
                    selectWeekdays.remove(at: itemToRemoveIndex)
                }
            }
            
        }
        else
        {
            btnMonday.isSelected = true
           weekday = "Mon"
             self.selectWeekdays.append(weekday)
        }
    }
    
    @IBAction func btnTuesdayTapped(_ sender: Any) {
        if ((sender as! UIButton).isSelected)
        {
            btnTuesday.isSelected = false
            while selectWeekdays.contains("Tues") {
                if let itemToRemoveIndex = selectWeekdays.index(of: "Tues") {
                    selectWeekdays.remove(at: itemToRemoveIndex)
                }
            }
            
        }
        else
        {
            btnTuesday.isSelected = true
            weekday = "Tues"
             self.selectWeekdays.append(weekday)
        }
    }
    
    @IBAction func btnWednesdayTapped(_ sender: Any) {
        if ((sender as! UIButton).isSelected)
        {
            btnWednesday.isSelected = false
            while selectWeekdays.contains("Wednes") {
                if let itemToRemoveIndex = selectWeekdays.index(of: "Wednes") {
                    selectWeekdays.remove(at: itemToRemoveIndex)
                }
            }
            
        }
        else
        {
            btnWednesday.isSelected = true
            weekday = "Wednes"
             self.selectWeekdays.append(weekday)
        }
    }
    
    @IBAction func btnThursdayTapped(_ sender: Any) {
        if ((sender as! UIButton).isSelected)
        {
            btnThursday.isSelected = false
            
            while selectWeekdays.contains("Thurs") {
                if let itemToRemoveIndex = selectWeekdays.index(of: "Thurs") {
                    selectWeekdays.remove(at: itemToRemoveIndex)
                }
            }
            
        }
        else
        {
            btnThursday.isSelected = true
            weekday = "Thurs"
             self.selectWeekdays.append(weekday)
        }
    }
    
    @IBAction func btnFridayTapped(_ sender: Any) {
        if ((sender as! UIButton).isSelected)
        {
            btnFriday.isSelected = false
            
            while selectWeekdays.contains("Fri") {
                if let itemToRemoveIndex = selectWeekdays.index(of: "Fri") {
                    selectWeekdays.remove(at: itemToRemoveIndex)
                }
            }
            
        }
        else
        {
            btnFriday.isSelected = true
            weekday = "Fri"
             self.selectWeekdays.append(weekday)
        }
    }
    
    @IBAction func btnSaturdayTapped(_ sender: Any) {
        if ((sender as! UIButton).isSelected)
        {
            btnSaturday.isSelected = false
            while selectWeekdays.contains("Satur") {
                if let itemToRemoveIndex = selectWeekdays.index(of: "Satur") {
                    selectWeekdays.remove(at: itemToRemoveIndex)
                }
            }
            
        }
        else
        {
            btnSaturday.isSelected = true
            weekday = "Satur"
             self.selectWeekdays.append(weekday)
        }
    }
}
extension UIView {
    func addBottomBorderWithColor(color: UIColor, width: CGFloat) {
        
        let border = CALayer()
        border.backgroundColor = color.cgColor
        border.frame = CGRect(x: 0, y: self.frame.size.height - width, width: frame.size.width, height: width)
        self.layer.addSublayer(border)
        let width1 = width
        if(width1 == 0){
            self.layer.replaceSublayer(border, with: border)
        }
    }
}
