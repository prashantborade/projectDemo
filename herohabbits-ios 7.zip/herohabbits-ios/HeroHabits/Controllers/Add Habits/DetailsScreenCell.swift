//
//  DetailsScreenCell.swift
//  HeroHabits
//
//  Created by aspl on 11/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class DetailsScreenCell: UITableViewCell {

  
    override func awakeFromNib() {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
