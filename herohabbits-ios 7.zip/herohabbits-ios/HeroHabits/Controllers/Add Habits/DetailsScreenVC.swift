//
//  DetailsScreenVC.swift
//  HeroHabits
//
//  Created by aspl on 11/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import FSCalendar

class DetailsScreenVC: UIViewController,FSCalendarDataSource,FSCalendarDelegate,FSCalendarDelegateAppearance,UITableViewDelegate,UITableViewDataSource{
    
    var nameArray = [String]()
    var imageArray = [String]()
    var scheduleArray = [String]()
    var statusArray = [String]()
    var deleteID:String?
    var getHabitTitle:String?

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var calender: FSCalendar!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = getHabitTitle!//"My Notes"
        
        nameArray = ["My Notes","Delete","Summary"]
        imageArray = ["mynote","mydelete","mygraph"]
        getHabitDetails()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailsScreenCell", for: indexPath) as! DetailsScreenCell
        
        cell.textLabel?.text = nameArray[indexPath.row]
        cell.imageView?.image = imageWithImage(image: UIImage(named: imageArray[indexPath.row])!, scaledToSize: CGSize(width: 30, height: 30))
        let image:UIImage = UIImage(named: "right_arrow")!
        let imageView = UIImageView(image: image)
        cell.accessoryView = imageView
        cell.accessoryView?.frame = CGRect(x: 0.0, y: 0.0, width: 30.0, height: 30.0)

        
    
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            let controller = storyboard?.instantiateViewController(withIdentifier: "MyNotesViewController") as! MyNotesViewController
            self.navigationController?.pushViewController(controller, animated: true)
        case 1:
            popupAlert(title: "Hero Habit", message: "Are you sure to delete this habit ?", actionTitles: ["Ok","Cancel"], actions: [{ (action1) in
//                self.nameArray.remove(at: indexPath.row)
//                self.tableView.reloadData()
                self.deleteCall()
                },{(action2) in
                    
                }])
            case 2:
                let controller = storyboard?.instantiateViewController(withIdentifier: "SummaryViewController") as! SummaryViewController
                controller.getString = "Summary"
                controller.getHabitController = UserDefaults.standard.value(forKey: "SummaryFlag") as? String
                self.navigationController?.pushViewController(controller, animated: true)
            break
        default:
            print("success")
        }
        
    }
    func buttonPressed(sender:UIButton!)
    {
        //let buttonRow = sender.tag
       
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }
    func imageWithImage(image:UIImage,scaledToSize newSize:CGSize)->UIImage{
        
        UIGraphicsBeginImageContext( newSize )
        image.draw(in: CGRect(x: 0,y: 0,width: newSize.width,height: newSize.height))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!.withRenderingMode(.alwaysOriginal)
    }
    
    func getHabitDetails(){
        var url = webConstant.baseUrl
        url.append(webConstant.habit_Details)
        
        let params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"habit_id":UserDefaults.standard.value(forKey: "habit_ID")!]
       // let params = ["user_id":"1","habit_id":"11"]
        print("params = >",params)
        requestGETURL(url, params: params as [String : AnyObject], success: { (data) in
            print("data = >",data)
            let status = data["status"].boolValue
           if !status{
                
            }else{
            let dataResult = data["resultdata"]["schedules"].arrayValue
            
            if dataResult.isEmpty {
//                self.popupAlert(title: "Hero Habit", message:"No Data", actionTitles: ["Ok"], actions:[{ (action1) in
//
//                    }])
            }else{
            var dataIterator = 0
            for scheduleList in data["resultdata"]["schedules"].arrayValue{
                let status = scheduleList["status"].stringValue
                let scheduleDate = scheduleList["scheduled_date"].stringValue
                
                self.scheduleArray.append(scheduleDate)
                self.statusArray.append(status)
                
                print(self.scheduleArray)
                print("statusArray = >",self.statusArray)
                
                dataIterator = dataIterator + 1
            }
            }
            self.calender.reloadData()
            }
        }) { (error) in
            print(error)
        }
    }
    
    fileprivate let formatter: DateFormatter = {
        let formatter = DateFormatter()
        
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        print("did select date \(self.formatter.string(from: date))")
        
        
    }
    
    func calendar(_ calendar: FSCalendar, didDeselect date: Date) {
        print("did deselect date \(self.formatter.string(from: date))")
       
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillDefaultColorFor date: Date) -> UIColor? {
        
        
        let dateString = formatter.string(from: date)
       // print("date = \(dateString)")
        if scheduleArray.contains(dateString){
            let index = scheduleArray.index(of: dateString)
            if statusArray[index!] == "0" {
                return UIColor.red
            }else {
                 return UIColor.green
            }

        }else {
            return nil
        }

        
    }
    
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at     monthPosition: FSCalendarMonthPosition) -> Bool{
        return false
    }
    func deleteCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.delete_habit)
        let parms = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"habit_id":UserDefaults.standard.value(forKey: "habit_ID")!]
        print(parms)
        requestGETURL(url, params:parms as [String : AnyObject]  , success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                   self.navigationController?.popViewController(animated: true)
                    }])
                
            }
        }) { (error) in
            print(error)
        }
    }
}
        

