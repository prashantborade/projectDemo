//
//  MyNotesViewController.swift
//  HeroHabits
//
//  Created by aspl on 11/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class MyNotesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UITextViewDelegate{
    
    var descriptionArray = [String]()
    var lastSeenArray = [String]()
    var addField:UITextField!
    var addString,noteID,notes:String?
    var idsArray = [String]()
    var timeArray = [String]()
    var noteArray = [String]()
    
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var btnAddCancel: UIButton!
    @IBOutlet weak var describeView: UITextView!
    @IBOutlet var addView: UIView!
    @IBOutlet weak var btnUpdate: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet var alertView: UIView!
    @IBOutlet weak var editView: UITextView!
    
    var theLabel: UILabel = {
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
        label.text = "No Data"
        return label
    }()

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLayoutSubviews() {
        /* Set the frame when the layout is changed */
        theLabel.center = CGPoint(x: self.view.frame.size.width / 2, y: self.view.frame.size.height / 2)
        theLabel.textAlignment = .center
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        describeView.text = "Add habit."
        
        describeView.textColor = UIColor.lightGray
        
      //  describeView.isScrollEnabled = true
        
        title = "My Notes List"
        self.tableView.contentInset = UIEdgeInsets(top: -35, left: 0, bottom: 0, right: 0)
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.estimatedRowHeight = UITableViewAutomaticDimension

       descriptionArray = ["poiuytrewlkjhgfdpoiuytrekjhgfdpoiuytrelkjhgfdspoiuytrewlkjhgfdspoiuytrewlkjhgfdsoiuytrejhgfdpoiuytrelkjhgf","poiuytrewqlkjhgfdsamnbvcxzpoiuytrewqlkjhgfdsamnbvcxz"]
        
       // alertView.frame = CGRect(x: 0.0, y: 0.0, width: view.frame.size.width/2, height: view.frame.size.height/2)
        
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
            if DeviceType.iPhone4orLess{
                alertView.frame = CGRect(x: 0.0, y: 0.0, width:300.0 , height: 440.0 )
                addView.frame = CGRect(x: 0.0, y: 0.0, width:300.0 , height: 440.0 )
            }else if DeviceType.iPhone5orSE{
                alertView.frame = CGRect(x: 0.0, y: 0.0, width: 300.0, height:520.0 )
                addView.frame = CGRect(x: 0.0, y: 0.0, width: 300.0, height:520.0 )
            }else if DeviceType.iPhone678{
                alertView.frame = CGRect(x: 0.0, y: 0.0, width: 350.0, height: 620.0)
                addView.frame = CGRect(x: 0.0, y: 0.0, width: 350.0, height: 620.0)
            }else if DeviceType.iPhone678p{
                alertView.frame = CGRect(x: 0.0, y: 0.0, width: 370.0, height: 650.0)
                addView.frame = CGRect(x: 0.0, y: 0.0, width: 370.0, height: 650.0)
            }else if DeviceType.iPhoneX{
                alertView.frame = CGRect(x: 0.0, y: 0.0, width: 350.0, height: 720.0)
                addView.frame = CGRect(x: 0.0, y: 0.0, width: 350.0, height: 720.0)
            }
            break
        case .pad:
            if DeviceType.IS_IPAD{
               // alertView.frame = CGRect(x: 0.0, y: 0.0, width: view.frame.size.width/2, height: view.frame.size.height/2)
                alertView.frame = CGRect(x: 0.0, y: 0.0, width: 740.0, height: 950.0)
                addView.frame = CGRect(x: 0.0, y: 0.0, width: 740.0, height: 950.0)
            }else if DeviceType.IS_IPAD_PRO{
                alertView.frame = CGRect(x: 0.0, y: 0.0, width: 740.0, height: 950.0)
                addView.frame = CGRect(x: 0.0, y: 0.0, width: 740.0, height: 950.0)
            }else{
                alertView.frame = CGRect(x: 0.0, y: 0.0, width: view.frame.size.width, height: view.frame.size.height)
                addView.frame = CGRect(x: 0.0, y: 0.0, width: view.frame.size.width, height: view.frame.size.height)
            }
            break
        case .unspecified:
            break
        case .tv:
            break
        case .carPlay:
            break
        }
      
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
         describeView.isScrollEnabled = true;
        getHabitDetails()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return noteArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MyNotesList
        cell.lblMyNotes.text = noteArray[indexPath.row]
//        let dateFormatter : DateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm a"
//        let date = Date()
//        let dateString = dateFormatter.string(from: date)
        cell.lblTimeNDate.text = timeArray[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    @available(iOS 11.0, *)
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let editAction = UIContextualAction(style: .normal, title: "Edit") { (action, view, completion) in
          //  self.tableView.reloadData()
            completion(true)
            
            self.noteID = self.idsArray[indexPath.row]
            //            self.notes = self.noteArray[indexPath.row]
//            let alert = UIAlertController(title: "", message: "Edit list item", preferredStyle: .alert)
//
//            alert.addTextField(configurationHandler: { (textField) in
//
//                textField.text = self.noteArray[indexPath.row]
//                textField.translatesAutoresizingMaskIntoConstraints = true
//                textField.sizeToFit()
//            })
//            alert.addAction(UIAlertAction(title: "Update", style: .default, handler: { (updateAction) in
//                self.notes = alert.textFields!.first!.text
//                self.editNoteCall()
//
//                //                self.noteArray[indexPath.row] = alert.textFields!.first!.text!
//                //                self.tableView.reloadRows(at: [indexPath], with: .fade)
//            }))
//            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//            self.present(alert, animated: false)
            self.editView.text = self.noteArray[indexPath.row]
            KGModal.sharedInstance().show(withContentView: self.alertView, andAnimated: true)
            KGModal.sharedInstance().closeButtonType = .none
            KGModal.sharedInstance().tapOutsideToDismiss = false
            KGModal.sharedInstance().modalBackgroundColor = UIColor.white
        
            
        }
        
        let deleteAction = UIContextualAction(style: .normal, title: "Delete") { (action, view, completion) in
            completion(true)
            self.popupAlert(title: "Hero Habit", message:"Are you sure to delete this note ?", actionTitles: ["Ok","Cancel"], actions:[{ (action1) in
                self.noteID = self.idsArray[indexPath.row]
                self.deleteNotesCall()
                },{ (action2) in
                    
                    
                }])
            
            action.backgroundColor = UIColor.red
        }
        
        editAction.backgroundColor = UIColor.lightGray
        deleteAction.backgroundColor = UIColor.red

        
        let config = UISwipeActionsConfiguration(actions: [deleteAction, editAction])
      
        config.performsFirstActionWithFullSwipe = false
        return config
        
    }
    
    @IBAction func btnAddTapped(_ sender: Any) {
       // KGModal.sharedInstance().hide(animated: true)
        let txtDescStr = describeView.text
        if(txtDescStr == "Add habit.")
        {
            
            let alert = UIAlertController(title: "Hero Habits", message: "Please add habit.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.default, handler: nil))
           alert.show()
        }
        else
        {
            self.addString = self.describeView.text
            self.addNotesCall()
            KGModal.sharedInstance().hide(animated: true)
        }
        
        
    }
    @IBAction func btnAddCancelTapped(_ sender: Any) {
        KGModal.sharedInstance().hide(animated: true)
    }
    

    @IBAction func btnCancelTapped(_ sender: Any) {
         KGModal.sharedInstance().hide(animated: true)
    }
    
    @IBAction func btnUpdateTapped(_ sender: Any) {
        let txtDescStr = editView.text
        if(txtDescStr == "")
        {
            
            let alert = UIAlertController(title: "Hero Habits", message: "Please add habit.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.default, handler: nil))
            alert.show()
        }
        else
        {
            self.notes = editView.text
            self.editNoteCall()
            KGModal.sharedInstance().hide(animated: true)
        }
        
    }
    
    @IBAction func btnAddClicked(_ sender: Any) {
        
        KGModal.sharedInstance().show(withContentView: self.addView, andAnimated: true)
        KGModal.sharedInstance().closeButtonType = .none
        KGModal.sharedInstance().tapOutsideToDismiss = false
        KGModal.sharedInstance().modalBackgroundColor = UIColor.white
        
//        let alert = UIAlertController(title: "Hero Habit", message: "Add Habit", preferredStyle: .alert)
//        alert.addTextField(configurationHandler: { (textField) in
//            textField.placeholder = "Add Habit"
//            let heightConstraint = NSLayoutConstraint(item: textField, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 40)
//            textField.addConstraint(heightConstraint)
//
//            self.addField = textField
//        })
//        alert.addAction(UIAlertAction(title: "Add", style: .default, handler: { (updateAction) in
//
//           self.addString = self.addField.text
//            self.addNotesCall()
////            print(self.addString!)
////            self.descriptionArray.append(self.addString!)
//            self.tableView.reloadData()
//        }))
//        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//        self.present(alert, animated: false)
    }
    func addNotesCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.add_notes)
        
        let params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"habit_id":UserDefaults.standard.value(forKey: "habit_ID")!,"note":addString!]
        requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    self.getHabitDetails()
                    //self.navigationController?.popViewController(animated: true)
                    }])
            }
        }) { (error) in
            print(error)
        }
    }
    
    func getHabitDetails(){
        var url = webConstant.baseUrl
     url.append(webConstant.habit_Details)
        
        let params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"habit_id":UserDefaults.standard.value(forKey: "habit_ID")!]
       //let params = ["user_id":"1","habit_id":"11"]
        
        requestGETURL(url, params: params as [String : AnyObject], success: { (data) in
            print("data = >",data)
            let status = data["status"].boolValue
            if !status{
                
            }else{
                let dataResult = data["resultdata"]["notes"].arrayValue
                if dataResult.isEmpty{
                    self.view.addSubview(self.theLabel)
                    self.idsArray.removeAll()
                    self.timeArray.removeAll()
                    self.noteArray.removeAll()
                }else{
               self.theLabel.removeFromSuperview()
                self.idsArray.removeAll()
                self.timeArray.removeAll()
                self.noteArray.removeAll()
                var dataIterator = 0
                for scheduleList in data["resultdata"]["notes"].arrayValue{
                    let ids = scheduleList["id"].stringValue
                    let time = scheduleList["time"].stringValue
                    let note = scheduleList["note"].stringValue
                    
                    self.idsArray.append(ids)
                    self.timeArray.append(time)
                    self.noteArray.append(note)
                    print(self.noteArray)
                    dataIterator = dataIterator + 1
                }
                }
                self.tableView.reloadData()
            }
        }) { (error) in
            print(error)
        }
    }
    
    func editNoteCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.edit_note)
        
        let params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"habit_id":UserDefaults.standard.value(forKey: "habit_ID")!,"note_id":noteID!,"note":notes!]
        
//         let params = ["user_id":"1","habit_id":"11","note_id":"1","note":"New note on 26th july,2018"]
        print("editParams = >",params)
        
        requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
            print("data = >",data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            
            if !status{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    
                    }])
            }else{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    self.getHabitDetails()
                    }])
            }
        }) { (error) in
            print(error)
        }
        
    }
    
    func deleteNotesCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.deleteNotes)
        
        let params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"note_id":noteID!]
        
        requestGETURL(url, params: params as [String : AnyObject], success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                   
                    }])
            }else{
                self.popupAlert(title: "Hero Habit", message:message, actionTitles: ["Ok"], actions:[{ (action1) in
                    self.getHabitDetails()
                    }])
            }
            
        }) { (error) in
            print(error)
        }
        
        
        
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if(textView.text == NSLocalizedString("Add habit.", comment: "")){
            textView.text = ""
        }
        textView .becomeFirstResponder()
    }
    
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text == ""){
            textView.text = "Add habit."
        }
        textView .resignFirstResponder()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        // Combine the textView text and the replacement text to
        // create the updated text string
        let currentText:String = textView.text
        let updatedText = (currentText as NSString).replacingCharacters(in: range, with: text)
        
        // If updated text view will be empty, add the placeholder
        // and set the cursor to the beginning of the text view
        if updatedText.isEmpty {
            
            textView.text = "Add habit."
            textView.textColor = UIColor.lightGray
            
            textView.selectedTextRange = textView.textRange(from: textView.beginningOfDocument, to: textView.beginningOfDocument)
        }
            
            // Else if the text view's placeholder is showing and the
            // length of the replacement string is greater than 0, set
            // the text color to black then set its text to the
            // replacement string
        else if textView.textColor == UIColor.lightGray && !text.isEmpty {
            textView.textColor = UIColor.black
            textView.text = text
        }
            
            // For every other case, the text should change with the usual
            // behavior...
        else {
            return true
        }
        
        // ...otherwise return false since the updates have already
        // been made
        return false
    }
   
   
}
