//
//  MyNotesList.swift
//  HeroHabits
//
//  Created by aspl on 11/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class MyNotesList: UITableViewCell {

    @IBOutlet weak var lblTimeNDate: UILabel!
    @IBOutlet weak var lblMyNotes: UILabel!
    @IBOutlet weak var card: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
       // card.setCardView()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
}
