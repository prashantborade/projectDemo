//
//  AddActivityVC.swift
//  HeroHabits
//
//  Created by aspl on 07/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class AddActivityVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
      var iconArray = [String]()
    
    var array:NSMutableArray = [];
    var imageArray : [String] = [];
    
    var categoryid_Array : [String] = [];
    var category_titleArray : [String] = [];
    var selected_categoryid = ""
    var activity_title,activity_icon,activitID:String?

    @IBOutlet weak var txtAddHabit: UITextField!
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Add Habit"
        
        for index in 1...32 {
            
            print("icon\(index)!")
            
            self.iconArray.append(("icon\(index)"))
            
            DispatchQueue.main.async {
                
             //   self.collectionView.reloadData()
            }
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getWebserviceCall()
        //getActivityListCall()
    }
    
    //MARK:- Button Action
    
    @IBAction func btnAddHabitClicked(_ sender: Any)
    {
//        let controller = storyboard?.instantiateViewController(withIdentifier: "ScheduleViewController") as! ScheduleViewController
//        self.navigationController?.pushViewController(controller, animated: true)
        
        if(selected_categoryid .isEmpty)
        {
            print("ALert for slect categoirs")
            self.popupAlert(title: "Hero Habits", message: "select activity", actionTitles: ["Ok"], actions: [{ (action1) in
                
                
                
                },{(action2) in
                    
                }])
            
        }else  if (txtAddHabit.text?.isEmpty)!
        {
            self.popupAlert(title: "Hero Habits", message: "Provide activity title", actionTitles: ["Ok"], actions: [{ (action1) in
                
                
                
                },{(action2) in
                    
                }])
        }
        else{
            print("selected_categoryid",selected_categoryid)
            print("selected_categoryTitle",txtAddHabit.text!)
            let user_id = UserDefaults.standard.value(forKey: "userID") as! String
            print("selected_categoryTitle",user_id)
            
          
            addActivityCall()
            
            
        }
    }
      //MARK:- Collection Delegate//
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        
        return 1;
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var sizes:CGSize? = nil
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
            sizes = CGSize(width: view.frame.size.width / 6, height: 40.0)
            break
            
        case .pad:
            sizes = CGSize(width: view.frame.size.width / 8, height: 80.0)
            break
            
        case .unspecified: break
        // Uh, oh! What could it be?
        case .tv:
            break
        case .carPlay:
            break
        }
        
        return sizes!
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AddActivityCell", for: indexPath) as! AddActivityCell
        
//        cell.img_AddActiviy.image = UIImage(named:iconArray[indexPath.row])
        cell.img_AddActiviy.contentMode = .scaleAspectFit
        

     
        let imagename =  self.imageArray[indexPath.row]
        
        print(imagename);
        cell.img_AddActiviy.sd_setImage(with: URL(string: imagename), placeholderImage: UIImage(named: "logoImage"))
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        print("category_title",[self.categoryid_Array[indexPath.row]])
        selected_categoryid = self.categoryid_Array[indexPath.row]
        
    }
    

    //MARK:- categoryList Webservice call
    
    func getWebserviceCall(){
        
            var url = webConstant.baseUrl
            url.append(webConstant.activity_list)
            print(url)
            let parms = ["category_id":UserDefaults.standard.value(forKey: "category_id")! as Any]
        print(parms)
        requestGETURL(url, params: parms as [String : AnyObject], success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                   
                }])
            }else{
                var dataIterator = 0
                for activityList in data["resultdata"].arrayValue{
                    self.activitID = activityList["activity_id"].stringValue
                    self.activity_icon = activityList["icon"].stringValue
                    
                    self.imageArray.insert(self.activity_icon!, at: dataIterator)
                    self.categoryid_Array.insert(self.activitID!, at: dataIterator)
                  
                    
                    dataIterator = dataIterator + 1
                }
                
            
                self.collectionView.reloadData()
            }
        }) { (error) in
            print(error)
        }
          
        
    }

     //MARK:- add_activity Webservice call
    
    func addActivityCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.add_activity)
        
        let user_id = UserDefaults.standard.value(forKey: "userID") as! String
        let parameter = ["activity_title":txtAddHabit.text! ,"activity_icon_id":selected_categoryid,"user_id":user_id,"category_id":UserDefaults.standard.value(forKey: "category_id")!]
        
        requestPOSTURL(url, params: parameter as [String : AnyObject], success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habits", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
        
                    },{(action2) in
                        
                    }])
            }else{
                
                self.popupAlert(title: "Hero Habits", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                    
                    self.navigationController?.popViewController(animated: true)
                   
                    },{(action2) in
                        
                    }])
            }
           
        }) { (error) in
            print(error)
        }
        
    }

}
