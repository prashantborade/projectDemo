//
//  AddCategoryCell.swift
//  HeroHabits
//
//  Created by aspl on 06/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class AddCategoryCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    
    override var isSelected: Bool{
        didSet{
            if self.isSelected
            {
                self.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
                self.contentView.backgroundColor = UIColor.lightGray
                //self.contentView.setCardView()
                self.contentView.layer.cornerRadius = 10
                //self.contentView.addBlurEffect()
               // self.imgView.isHidden = false
            }
            else
            {
                self.transform = CGAffineTransform.identity
                self.contentView.backgroundColor = UIColor.clear
                //self.imgView.isHidden = true
            }
        }
    }
    
}
