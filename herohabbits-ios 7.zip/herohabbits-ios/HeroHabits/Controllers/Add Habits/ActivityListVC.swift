//
//  ActivityListVC.swift
//  HeroHabits
//
//  Created by aspl on 07/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class ActivityListVC: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var activityDataSet = [Activity]()
    var totalActivityDataSet = [Activity]()
    
    var imgActivityListArray = [String]()
    var titleActivityListArray = [String]()
    var selectedArray = [String]()

    var iconArray = [String]()
    var array_main:NSMutableArray = [];
    var imageArray : [String] = [];
    
    var categoryid_Array : [String] = [];
    var category_titleArray : [String] = [];
    var selected_categoryid = ""
    
    var categoryID = [String]()
    var totalCategoryID = [String]()
    var deleteID:String!
    var categorySelection:String!
    var getCategoryTitle:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = getCategoryTitle!//"Health"
        //activityListCall()
      
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
     
        activityListCall()
      
        
    }

    @IBAction func btnActivityListClicked(_ sender: Any) {
        let controller = storyboard?.instantiateViewController(withIdentifier: "AddActivityVC") as! AddActivityVC
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return totalActivityDataSet.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ActivityList
        
        let imagename =  self.totalActivityDataSet[indexPath.row].activity_image
        cell.img_ActivityList.sd_setImage(with: URL(string: imagename), placeholderImage: UIImage(named: "logoImage"))
        cell.lbl_ActivityList.text = self.totalActivityDataSet[indexPath.row].activity_title
        
        
//        cell.img_ActivityList.image = UIImage(named: imgActivityListArray[indexPath.row])
//        cell.lbl_ActivityList.text = titleActivityListArray[indexPath.row]
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let activity_id = totalActivityDataSet[indexPath.row].activity_id
        UserDefaults.standard.set(activity_id, forKey: "activity_id")
        print(activity_id)
        let controller = storyboard?.instantiateViewController(withIdentifier: "ScheduleViewController") as! ScheduleViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
   
    

    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        
        
        let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
            self.deleteID = self.totalActivityDataSet[indexPath.row].activity_id
            print(self.deleteID)
           
            self.ActivityDeleteCall()
            //            self.titleCategoryArray.remove(at: indexPath.row)
            //            self.imgCategoryArray.remove(at: indexPath.row)
            // self.categoryTableView.reloadData()
        })
        
        return [deleteAction]
    }
    
    //MARK:- WebService call
    func activityListCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.user_activity_list)
        
        let parms = ["user_id":UserDefaults.standard.value(forKey: "userID")!,
                     "category_id":categorySelection!]
        requestGETURL(url, params: parms as [String : AnyObject], success: { (data) in
            print(data)
            
            let status = data["status"].boolValue
            if !status{
                
            }else{
                self.activityDataSet.removeAll()
                self.totalActivityDataSet.removeAll()
                var dataIterator = 0
                for activityList in data["resultdata"].arrayValue{
                    let activityIconId = activityList["activity_icon_id"].stringValue
                    let activityId = activityList["activity_id"].stringValue
                    let activityImage = activityList["activity_image"].stringValue
                    let activityTittle = activityList["activity_title"].stringValue
                    
                    self.activityDataSet.append(Activity(iconID: activityIconId, activityID: activityId, image: activityImage, tittle: activityTittle))
                    
                    self.totalActivityDataSet = self.activityDataSet
                    
                    dataIterator = dataIterator + 1
                    
                }
                self.tableView.reloadData()
            }
        }) { (error) in
            print(error)
        }
    }
    
    func ActivityDeleteCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.delete_activity)
        
        let parms = ["user_id":UserDefaults.standard.value(forKey: "userID")!,
                     "activity_id":deleteID!]
        
        
        requestGETURL(url, params: parms as [String : AnyObject], success: { (data) in
            print(data)
            let status = data["status"].boolValue
            
            if !status{
                
            }else{
                self.activityListCall()
            }
        }) { (error) in
            print(error)
        }
    }

}
class Activity{
    let activity_icon_id:String
    let activity_id:String
    let activity_image:String
    let activity_title:String
    
    init(iconID:String,activityID:String,image:String,tittle:String) {
        
        self.activity_icon_id = iconID
        self.activity_id = activityID
        self.activity_image = image
        self.activity_title = tittle
    }
}
