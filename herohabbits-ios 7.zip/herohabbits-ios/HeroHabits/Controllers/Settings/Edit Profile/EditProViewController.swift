//
//  EditProViewController.swift
//  HeroHabits
//
//  Created by aspl on 01/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import SwiftyJSON
import SDWebImage

class EditProViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var btnUpdate: UIButton!
    
    @IBOutlet weak var lblFullname: UILabel!
    @IBOutlet weak var txtPincode: TextField!
    @IBOutlet weak var txtAddress: TextField!
    @IBOutlet weak var txtEmail: TextField!
    @IBOutlet weak var txtDateOfBirth: TextField!
    @IBOutlet weak var txtLastname: TextField!
    @IBOutlet weak var txtFirstname: TextField!
    @IBOutlet weak var profileImage: UIImageView!
    
    @IBOutlet weak var imageOfHeight: NSLayoutConstraint!
    
    @IBOutlet weak var imageOfWidth: NSLayoutConstraint!
    
    @IBOutlet weak var sampleImage: UIImageView!
    
  var chooseArray = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
      //  sampleImage.backgroundColor = sampleIm
        chooseArray = ["Camera","Gallery"]
      
        title = "Edit Profile"
        profileImage.setCardView()
        //self.profileImage.layer.borderWidth = 0.2
        
//        let rightButton: UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "home"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(self.wayToHome))
//        navigationItem.rightBarButtonItem = rightButton
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.profileImage.isUserInteractionEnabled = true
       self.profileImage.addGestureRecognizer(tapGestureRecognizer)
        
        let datePicker = UIDatePicker()
        datePicker.date = Date()
        datePicker.datePickerMode = .date
        datePicker.addTarget(self, action: #selector(self.dateTextField(_:)), for: .valueChanged)
        txtDateOfBirth.inputView = datePicker
//        self.profileImage.layer.cornerRadius = self.profileImage.frame.width / 2.0
//        self.profileImage.layer.borderColor = UIColor.black.cgColor
//        self.profileImage.layer.borderWidth = 0.5
//        self.profileImage.layer.masksToBounds = true
//       // self.profileImage.clipsToBounds = true
//        self.profileImage.contentMode = .scaleToFill
       self.profileImage.makeCircle()
        
        getProfileCall()
      
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
    }
    
    @objc public func wayToHome() {
//        for controller in self.navigationController!.viewControllers as Array {
//
//                                    if controller.isKind(of: MainViewController.self) {
//
//                                        self.navigationController!.popToViewController(controller, animated: true)
//                                        break
//                                    }
//                                }
    }
    
    @objc func dateTextField(_ sender: Any?) {
        let picker = txtDateOfBirth.inputView as? UIDatePicker
        picker?.maximumDate = Date()
        let dateFormat = DateFormatter()
        let eventDate: Date? = picker?.date
        dateFormat.dateFormat = "yyyy-MM-dd"
        var dateString: String? = nil
        if let aDate = eventDate {
            dateString = dateFormat.string(from: aDate)
        }
        txtDateOfBirth.text = "\(dateString ?? "")"
    }

    @IBAction func BtnUpdateTapped(_ sender: Any) {
       if (txtFirstname.text?.isEmpty)!{
            popupAlert(title: "Hero Habits", message: "Please Enter Your First Name", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
       }else if (txtLastname.text?.isEmpty)!{
        popupAlert(title: "Hero Habits", message: "Please Enter Your Last Name", actionTitles: ["Ok"], actions: [{ (action1) in
            },{(action2) in
                
            }])
        }
       else if (txtEmail.text?.isEmpty)!{
        popupAlert(title: "Hero Habits", message: "Please Enter Your Email Address", actionTitles: ["Ok"], actions: [{ (action1) in
            },{(action2) in
                
            }])
        
       }else if !isValidEmail(testStr: txtEmail.text!){
        popupAlert(title: "Hero Habits", message: "Please Enter Correct E-mail Address", actionTitles: ["Ok"], actions: [{ (action1) in
            },{(action2) in
                
            }])
       }
       else if (txtDateOfBirth.text?.isEmpty)!{
        popupAlert(title: "Hero Habits", message: "Please Enter Your Date Of Birth", actionTitles: ["Ok"], actions: [{ (action1) in
            },{(action2) in
                
            }])
       }/*else if (txtAddress.text?.isEmpty)!{
        popupAlert(title: "Hero Habits", message: "Please Enter Your Address", actionTitles: ["Ok"], actions: [{ (action1) in
            },{(action2) in
                
            }])
        }*/else{
             //getWebserviceData()
            editUploadCall()
        }
       
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
      
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        for app in chooseArray {
            let s4 = UIAlertAction(title: app, style: .default, handler: { action in
                if app == "Camera" {
                    let picker = UIImagePickerController()
                    picker.delegate = self
                    picker.allowsEditing = true
                    picker.sourceType = .camera
                    self.present(picker, animated: true)
                }
                let picker = UIImagePickerController()
                picker.delegate = self
                picker.allowsEditing = true
                picker.sourceType = .photoLibrary
                self.present(picker, animated: true)
            })
            alertController.addAction(s4)
        }
        let s5 = UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
        })
        alertController.addAction(s5)
        alertController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
        alertController.popoverPresentationController?.sourceRect = CGRect(x: view.center.x, y: view.center.y, width: 0, height: 0)
        
        alertController.popoverPresentationController?.permittedArrowDirections = UIPopoverArrowDirection(rawValue: 0)
        // present the view controller
        self.present(alertController, animated: true, completion: nil)
//
//        present(alertController, animated: true)
   }
    
       @objc func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
            // output image
        
            let chosenImage = info[UIImagePickerControllerOriginalImage] as? UIImage
            profileImage.image = chosenImage
       
           // profileImage.image = info[UIImagePickerControllerOriginalImage] as? UIImage
            picker.dismiss(animated: true)
        }
 
    @IBAction func btnUpdateTapped(_ sender: Any) {
//        UIImageWriteToSavedPhotosAlbum(profileImage.image!, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            // we got back an error!
            let ac = UIAlertController(title: "Save error", message: error.localizedDescription, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        } else {
            let ac = UIAlertController(title: "Saved!", message: "Your altered image has been saved to your photos.", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        }
    }
    
    func editUploadCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.update_Profile)
        
        let imgData = UIImageJPEGRepresentation(profileImage.image!, 0.2)
        
        let parameters = ["id":UserDefaults.standard.value(forKey: "userID")! ,
                          "first_name":txtFirstname.text!,
                          "last_name":txtLastname.text!,
                          "email":txtEmail.text!,
                          "dob":txtDateOfBirth.text!,
                          "address":""]
        uploadImageWithData(url, params: parameters as [String : AnyObject], multipleImageData: nil,imageData: imgData, success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message = data["message"].stringValue
            
            if !status{
                self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                    self.navigationController?.popViewController(animated: true)
                    }])
            }else{
                let dob = data["resultdata"]["dob"].stringValue
                let email = data["resultdata"]["email"].stringValue
                let firstName = data["resultdata"]["first_name"].stringValue
                let lastName = data["resultdata"]["last_name"].stringValue
                let profileImage = data["resultdata"]["profile_image"].stringValue
                
                let fullname = firstName + " " + lastName
                self.lblFullname.text = fullname
                self.txtFirstname.text = firstName
                self.txtLastname.text = lastName
                self.txtEmail.text = email
                // self.txtAddress.text = address
                self.txtDateOfBirth.text = dob
                
                let url = URL(string: profileImage)
                let data = try? Data(contentsOf: url!)
                
                if let imageData = data {
                    let image = UIImage(data: imageData)
                    self.profileImage.image = image
                }
                
                
                self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                    self.navigationController?.popViewController(animated: true)
                    }])
            }
        }) { (error) in
            print(error)
        }
        
    }

    func getProfileCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.profile_Details)
        
        let parameters = ["id":UserDefaults.standard.value(forKey: "userID")!]
        
        requestPOSTURL(url, params: parameters as [String : AnyObject], success: { (data) in
            print(data)
            
            let dob = data["dob"].stringValue
            let lastName = data["last_name"].stringValue
            let firstName = data["first_name"].stringValue
            let email = data["email"].stringValue
            let profileImage = data["profile_image"].stringValue
            _ = data["address"].stringValue
            let fullname = firstName + " " + lastName
            self.lblFullname.text = fullname
            self.txtEmail.text = email
            self.txtLastname.text = lastName
            self.txtFirstname.text = firstName
            self.txtDateOfBirth.text = dob
            //self.txtAddress.text = address
            self.profileImage.sd_setImage(with: URL(string: profileImage), placeholderImage: UIImage(named: "logoImage"))
            // UserDefaults.standard.set(fullname, forKey: "userName")
            UserDefaults.standard.set(profileImage, forKey: "profileImage")
        }) { (error) in
            print(error)
        }
    }
    
}
