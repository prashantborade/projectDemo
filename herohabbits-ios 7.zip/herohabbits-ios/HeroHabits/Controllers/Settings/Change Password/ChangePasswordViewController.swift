//
//  ChangePasswordViewController.swift
//  HeroHabits
//
//  Created by aspl on 31/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class ChangePasswordViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var btnUpdate: UIButton!
    @IBOutlet weak var txtConfirmPassword: UITextField!
    @IBOutlet weak var txtNewPassword: UITextField!
    @IBOutlet weak var txtCurrentPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    
        title = "Change Password"
        txtCurrentPassword.delegate = self
        txtNewPassword.delegate = self
        txtConfirmPassword.delegate = self
    
        btnUpdate.addTarget(self, action: #selector(btnUpdateClicked), for: .touchUpInside)
    }
    
    @objc func btnUpdateClicked(){
        guard let currentPassword = txtCurrentPassword.text, !currentPassword.isEmpty else {
            popupAlert(title: "Hero Habits", message: "Please Enter Your Current Password", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
            return
        }
        
        guard let newPassword = txtNewPassword.text, !newPassword.isEmpty else {
            popupAlert(title: "Hero Habits", message: "Please Enter Your New Password", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
            return
        }
        
        guard let parse = txtNewPassword.text, !(parse.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil) else {
            popupAlert(title: "Hero Habit", message: "Password do not accept space as Password", actionTitles: ["Ok"], actions: [{(action1) in
                
                }])
            return
        }
        
        guard let confirmPassword = txtConfirmPassword.text, !confirmPassword.isEmpty else {
            popupAlert(title: "Hero Habits", message: "Please Enter Your Confirm Password", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
            return
        }
        guard let confirmPass = txtConfirmPassword.text, !(confirmPass.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil) else {
            popupAlert(title: "Hero Habit", message: "Password do not accept space as Password", actionTitles: ["Ok"], actions: [{(action1) in
                
                }])
            return
        }
        
        guard newPassword == confirmPassword else {
            popupAlert(title: "Hero Habits", message: "New Password and Confirm Password does not Match", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
            return
        }
       

            
            ChangPasswordCall()
  
       
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        return true
    }
    
    
    
    func ChangPasswordCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.change_password)
        
        let params:Dictionary  = ["user_id":UserDefaults.standard.value(forKey: "userID")!,
                                  "current_password":txtCurrentPassword.text!,
                                  "new_password":txtNewPassword.text!]
        
        requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
            let status = data["status"].boolValue
            
            if !status{
                
            }else{
                self.popupAlert(title: "Hero Habit", message: data["message"].stringValue, actionTitles: ["Ok"], actions:[{(action) in
                    
                    self.navigationController?.popViewController(animated: true)
                    }])
            }
            
        }) { (error) in
            print(error)
        }
    }

    
}
