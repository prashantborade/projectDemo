//
//  SettingsViewController.swift
//  HeroHabits
//
//  Created by aspl on 31/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import GoogleSignIn

class SettingsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var imgSettingArray = [String]()
    var nameSettingArray = [String]()
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

       setNavigate()
        title = "Settings"
        
        imgSettingArray = ["editPro","changePassword","aboutApp","contactUs","logout"]
        nameSettingArray = ["Edit Profile","Change Password","About App","Contact Us","Logout"]
        
        self.tableView.rowHeight = UITableViewAutomaticDimension;
        self.tableView.estimatedRowHeight = UITableViewAutomaticDimension
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
       
       
      //  GIDSignIn.sharedInstance().signIn()
    }
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        let currentValue = CGFloat(sender.value)
        UIScreen.main.brightness = currentValue
    }
   
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.nameSettingArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "settingCell", for: indexPath) as! SettingsList
        let imageData = imgSettingArray[indexPath.row]
        cell.img_Setting.image = UIImage(named: imageData)
        cell.lblSetting.text = nameSettingArray[indexPath.row]
        cell.contentView.setCardView()
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            let controller = storyboard?.instantiateViewController(withIdentifier: "EditProViewController") as! EditProViewController
            self.navigationController?.pushViewController(controller, animated: true)
        case 1:
            let controller = storyboard?.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
            self.navigationController?.pushViewController(controller, animated: true)
        case 2:
            let controller = storyboard?.instantiateViewController(withIdentifier: "AboutAppViewController") as! AboutAppViewController
            self.navigationController?.pushViewController(controller, animated: true)
            
        case 3:
            let controller = storyboard?.instantiateViewController(withIdentifier: "ContactUsViewController") as! ContactUsViewController
            self.navigationController?.pushViewController(controller, animated: true)
        case 4:
            popupAlert(title: "Logout", message: "Do you want to logout app ?", actionTitles: ["Yes","No"], actions: [{ (action1) in
                GIDSignIn.sharedInstance().signOut()
                let controller = self.storyboard?.instantiateViewController(withIdentifier: "SignInViewController") as! SignInViewController
                self.navigationController?.pushViewController(controller, animated: true)
                },{(action2) in
                    
                }])
        default:
            print("success")
            
        }
    }
}
