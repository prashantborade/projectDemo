//
//  ContactUsViewController.swift
//  HeroHabits
//
//  Created by aspl on 04/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class ContactUsViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate {

    @IBOutlet weak var contactTextView: UITextView!
    @IBOutlet weak var btn_Three: UIButton!
    @IBOutlet weak var btn_Two: UIButton!
    @IBOutlet weak var btn_One: UIButton!
    
    @IBOutlet weak var FirstImage: UIImage!
    @IBOutlet weak var secondImage: UIImage!
    @IBOutlet weak var thirdImage: UIImage!
 
    @IBOutlet weak var card: UIView!
    @IBOutlet weak var textViewContact: UITextView!
    
     var  flagImage:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Contact Us"
       textViewContact.setCardView()
        card.setCardView()
        textViewContact.text = "Describe your message."
       
        textViewContact.textColor = UIColor.lightGray
        
        textViewContact.isScrollEnabled = false;
        
    }
    override func viewWillAppear(_ animated: Bool) {
        textViewContact.isScrollEnabled = true;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnOneTapped(_ sender: Any) {
        flagImage = "first";
        self.getScrrenShotFromGallery()
        
        }
    
    
    @IBAction func btnTwoTapped(_ sender: Any) {
        flagImage = "second";
        self.getScrrenShotFromGallery()
    }
    
    @IBAction func btnThreeTapped(_ sender: Any) {
        flagImage = "third";
        self.getScrrenShotFromGallery()
    }
    
    func getScrrenShotFromGallery()
    {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary)
        {
            let imagePicker = UIImagePickerController()
           imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            //                profilePic.contentMode = .scaleToFill
            //                profilePic.image = pickedImage
            
            if flagImage == "first"{
                
                btn_One.setImage(pickedImage, for: .normal) ;
                FirstImage = pickedImage;
            }
            else if flagImage == "second"
            {
                btn_Two.setImage(pickedImage, for: .normal) ;
                secondImage = pickedImage;
            }
            else
            {
                btn_Three.setImage(pickedImage, for: .normal) ;
                thirdImage = pickedImage;
            }
        }
        picker.dismiss(animated: true, completion: nil)
    }
    // MARK:- keyboard hide
    func textViewDidBeginEditing(_ textView: UITextView) {
        if(textView.text == NSLocalizedString("Describe your message.", comment: "")){
            textView.text = ""
        }
        textView .becomeFirstResponder()
    }
    
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text == ""){
            textView.text = "Describe your message."
        }
        textView .resignFirstResponder()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        // Combine the textView text and the replacement text to
        // create the updated text string
        let currentText:String = textView.text
        let updatedText = (currentText as NSString).replacingCharacters(in: range, with: text)
        
        // If updated text view will be empty, add the placeholder
        // and set the cursor to the beginning of the text view
        if updatedText.isEmpty {
            
            textView.text = "Describe your message."
            textView.textColor = UIColor.lightGray
            
            textView.selectedTextRange = textView.textRange(from: textView.beginningOfDocument, to: textView.beginningOfDocument)
        }
            
            // Else if the text view's placeholder is showing and the
            // length of the replacement string is greater than 0, set
            // the text color to black then set its text to the
            // replacement string
        else if textView.textColor == UIColor.lightGray && !text.isEmpty {
            textView.textColor = UIColor.black
            textView.text = text
        }
            
            // For every other case, the text should change with the usual
            // behavior...
        else {
            return true
        }
        
        // ...otherwise return false since the updates have already
        // been made
        return false
    }
    
    @IBAction func sendMessageClicked(_ sender: Any)
    {
        let txtDescStr = textViewContact.text
        if(txtDescStr == "Describe your message.")
        {
            
            let alert = UIAlertController(title: "Hero Habits", message: "Please provide decription.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
          
           uploadImageToServer()
        }
        
    }
    
    func uploadImageToServer(){
        
        let user_id = UserDefaults.standard.value(forKey: "userID") as! String
        var url = webConstant.baseUrl
        url.append(webConstant.contact_us)
        
        let parameters = ["user_id":user_id ,
                          "message":textViewContact.text!]
        
        let imgData1 = UIImageJPEGRepresentation((btn_One.imageView?.image)!, 0.2)
        let imgData2 = UIImageJPEGRepresentation((btn_Two.imageView?.image)!, 0.2)
        let imgData3 = UIImageJPEGRepresentation((btn_Three.imageView?.image)!, 0.2)
        
        
        uploadImageWithData(url, params: parameters as [String : AnyObject], multipleImageData: [imgData1!,imgData2!,imgData3!],imageData:nil , success: { (data) in
            print(data)
            let resp = data["resp"].boolValue
            let message = data["message"].stringValue
            if !resp{
                self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                    self.navigationController?.popViewController(animated: false)
                    }])
            }else{
                
               self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                  self.navigationController?.popViewController(animated: false)
                }])
            }
        }) { (error) in
            print(error)
        }
    }
   
   
    
    
}
