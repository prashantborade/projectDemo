//
//  SettingsList.swift
//  HeroHabits
//
//  Created by aspl on 01/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class SettingsList: UITableViewCell{

    @IBOutlet weak var card: UIView!
    @IBOutlet weak var img_Setting: UIImageView!
    @IBOutlet weak var lblSetting: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        //card.setCardView()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
