//
//  AboutAppViewController.swift
//  HeroHabits
//
//  Created by aspl on 04/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class AboutAppViewController: UIViewController {

    @IBOutlet weak var txtContentView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "About App"
       
        getAboutCall()
    }
    

    
    func getAboutCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.about_Us)
        
        requestGETURL(url, params: nil, success: { (data) in
            let status = data["status"].boolValue
            
            if !status{
                
            }else{
                let content = data["resultdata"]["content"].stringValue
                self.txtContentView.text = content
            }
           
        }) { (error) in
            print(error)
        }
    }

}

