//
//  SummaryViewController.swift
//  HeroHabits
//
//  Created by aspl on 31/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class SummaryViewController: UIViewController {
    
    var imgSummaryArray = [String]()
    var totalSummaryArray = [String]()
    var totalPointsArray = [String]()
    var totalPointDataSet = [String]()
    var totalSummaryDataSet = [Summary]()
    var SummaryDataSet = [Summary]()
    var getString:String?
    var getHabitController:String?
     var App_Link : String = ""
    var trackedHabit,missedHabit,perfectDays,averageDays,totalPoints:String?
   

    @IBOutlet weak var lblTotalPoints: UILabel!
    @IBOutlet weak var img_Summary: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var lblTotalEarned: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        setNavigate()
        title = "Summary"
//        let rightButton: UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "Share"), style: UIBarButtonItemStyle.plain, target: self, action: #selector(self.toggle))
//        navigationItem.rightBarButtonItem = rightButton
        
       
       
        if getString == "Summary"{
            totalSummaryArray = ["Total perfect days","Total habits done","Total habits not done","Average per day","Current Streak","Best streak"]
            totalPointsArray = ["200","100","100","100"]
            imgSummaryArray = ["icon20","icon9","icon34","icon18","current","best"]
            getHabitDetails()
        }else{
            totalSummaryArray = ["Total perfect days","Total habits done","Total habits not done","Average per day"]
            totalPointsArray = ["200","100","100","100"]
            imgSummaryArray = ["icon20","icon9","icon34","icon18"]
            
            summaryCall()
            self.tableView.reloadData()
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if getHabitController == "TodayHabit"{
            
        }else if getHabitController == "OrderHabit"{
            
        }else{
            self.setNavigationBarItem()
            if getString == "Summary"{
                totalSummaryArray = ["Total perfect days","Total habits done","Total habits not done","Average per day","Current Streak","Best streak"]
                totalPointsArray = ["200","100","100","100"]
                imgSummaryArray = ["icon20","icon9","icon34","icon18","icon18","icon18"]
                getHabitDetails()
            }else{
                totalSummaryArray = ["Total perfect days","Total habits done","Total habits not done","Average per day"]
                totalPointsArray = ["200","100","100","100"]
                imgSummaryArray = ["icon20","icon9","icon34","icon18"]
                
                summaryCall()
                self.tableView.reloadData()
            }
            
        }
        
       
    }
    @objc  func toggle(){
        let text = self.App_Link
        
        // set up activity view controller
        let textToShare = [ text ]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
        activityViewController.popoverPresentationController?.sourceRect = CGRect(x: view.center.x, y: view.center.y, width: 0, height: 0)
        
        activityViewController.popoverPresentationController?.permittedArrowDirections = UIPopoverArrowDirection(rawValue: 0)
        // present the view controller
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    
    @IBAction func btnShareTapped(_ sender: Any) {
        let text = self.App_Link
        
        // set up activity view controller
        let textToShare = [ text ]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view // so that iPads won't crash
        activityViewController.popoverPresentationController?.sourceRect = CGRect(x: view.center.x, y: view.center.y, width: 0, height: 0)
        
        activityViewController.popoverPresentationController?.permittedArrowDirections = UIPopoverArrowDirection(rawValue: 0)
        // present the view controller
        self.present(activityViewController, animated: true, completion: nil)
    }
    
  
}
extension SummaryViewController: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.totalPointDataSet.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "summaryCell", for: indexPath) as! SummaryList
        
        cell.lbl_TotalName.text = totalSummaryArray[indexPath.row]
        cell.lbl_TotalPoints.text = totalPointDataSet[indexPath.row]

        let selectImage = imgSummaryArray[indexPath.row]
        cell.img_SummaryCell.image = UIImage(named: selectImage)
        
        return cell
    }
    func summaryCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.summary)
        
        let params = ["user_id":UserDefaults.standard.value(forKey: "userID")!]
        
        requestGETURL(url, params: params as [String : AnyObject], success: { (data) in
            print("data",data)
            let status = data["status"].boolValue
            if !status{
                
            }else{
                self.trackedHabit = data["resultdata"]["tracked_habit"].stringValue
                self.missedHabit = data["resultdata"]["missed_habit"].stringValue
                self.perfectDays = data["resultdata"]["perfect_days"].stringValue
                self.averageDays = data["resultdata"]["avg_per_day"].stringValue
                self.totalPoints = data["resultdata"]["total_earned"].stringValue
                let avg = String(format: "%.2f", Double(self.averageDays!)!)
                print(avg)
              
                self.totalPointDataSet.removeAll()
                self.totalPointDataSet.insert(self.perfectDays!, at: 0)
                self.totalPointDataSet.insert(self.trackedHabit!, at: 1)
                self.totalPointDataSet.insert(self.missedHabit!, at: 2)
                self.totalPointDataSet.insert(avg, at: 3)
                
                print(self.totalPointDataSet)
                print(self.totalPoints!)
                self.App_Link = "Total Earned :-" + " " + self.totalPoints!
                self.lblTotalEarned.text = self.totalPoints!
                self.tableView.reloadData()
            }
            
            
        }) { (error) in
            print(error)
        }
    }
    func getHabitDetails(){
        var url = webConstant.baseUrl
        url.append(webConstant.habit_Details)
        
        let params = ["user_id":UserDefaults.standard.value(forKey: "userID")!,"habit_id":UserDefaults.standard.value(forKey: "habit_ID")!]
        // let params = ["user_id":"1","habit_id":"11"]
        print("params = >",params)
        requestGETURL(url, params: params as [String : AnyObject], success: { (data) in
            print("data = >",data)
            let status = data["status"].boolValue
            if !status{
                
            }else{
                self.trackedHabit = data["resultdata"]["summary"]["tracked_habits"].stringValue
                self.missedHabit = data["resultdata"]["summary"]["missed_habits"].stringValue
                self.perfectDays = data["resultdata"]["summary"]["perfect_days"].stringValue
                self.averageDays = data["resultdata"]["summary"]["avg_per_day"].stringValue
                self.totalPoints = data["resultdata"]["summary"]["total_earned"].stringValue
                let currentStreak = data["resultdata"]["summary"]["current_streak"].stringValue
                let bestStreak = data["resultdata"]["summary"]["best_streak"].stringValue
                 let avg = String(format: "%.2f", Double(self.averageDays!)!)
                
                self.totalPointDataSet.insert(self.perfectDays!, at: 0)
                self.totalPointDataSet.insert(self.trackedHabit!, at: 1)
                self.totalPointDataSet.insert(self.missedHabit!, at: 2)
                self.totalPointDataSet.insert(avg, at: 3)
                self.totalPointDataSet.insert(currentStreak, at: 4)
                self.totalPointDataSet.insert(bestStreak, at: 5)
                
                print(self.totalPointDataSet)
                print(self.totalPoints!)
                self.lblTotalEarned.text = self.totalPoints!
                self.tableView.reloadData()
            }
            
        }) { (error) in
            print(error)
        }
    }
}

class Summary{
    let trackHabit:String
    let missedHabit:String
    let perfectDays:String
    let avgDays:String
    let totalEarned:String
    init(tracked_habit:String,missed_habit:String,perfect_days:String,avg_per_day:String,total_earned:String) {
        self.trackHabit = tracked_habit
        self.missedHabit = missed_habit
        self.perfectDays = perfect_days
        self.avgDays = avg_per_day
        self.totalEarned = total_earned
    }
}
