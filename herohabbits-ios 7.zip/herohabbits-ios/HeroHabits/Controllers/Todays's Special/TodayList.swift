//
//  TodayList.swift
//  HeroHabits
//
//  Created by aspl on 01/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import WebKit

class TodayList: UICollectionViewCell {
    @IBOutlet weak var img_Today: UIImageView!
    
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    
    @IBOutlet weak var btnPlay: UIButton!
    
   
    @IBOutlet weak var webView: UIWebView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.webView.delegate = self
        //indicator.stopAnimating()
        // Initialization code
    }
    
    
}
extension TodayList : UIWebViewDelegate
{
    public func webViewDidStartLoad(_ webView: UIWebView) {
        debugPrint("Start Loading")
        indicator.startAnimating()
    }
    
    public func webViewDidFinishLoad(_ webView: UIWebView) {
        indicator.isHidden = true
        indicator.stopAnimating()
    }
}

