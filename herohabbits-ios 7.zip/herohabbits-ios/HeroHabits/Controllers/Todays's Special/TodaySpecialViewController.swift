//
//  TodaySpecialViewController.swift
//  HeroHabits
//
//  Created by aspl on 31/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class TodaySpecialViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIWebViewDelegate {
    
    @IBOutlet weak var widthFirstView: NSLayoutConstraint!
    @IBOutlet weak var leadingFirstView: NSLayoutConstraint!
    @IBOutlet weak var trailingFirstView: NSLayoutConstraint!
    
    @IBOutlet weak var secondView: UIView!
    @IBOutlet weak var FirstView: UIView!
    
    @IBOutlet weak var btnImages: UIButton!
    @IBOutlet weak var btnVideos: UIButton!
    
    @IBAction func btnImageTapped(_ sender: Any) {
        flag = "Images"
      
        FirstView.isHidden = false
        FirstView.layer.cornerRadius = 1.0
         self.leadingFirstView.constant = 0.0
        UIView.animate(withDuration: 1, animations: {
           self.view.layoutIfNeeded()
         // self.FirstView.frame.origin.x = 0.0
        }, completion: nil)
        todaySpecialCall()
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
             btnImages.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16.0)
             btnVideos.titleLabel?.font = UIFont.systemFont(ofSize: 16.0)
            break
        case .pad:
             btnImages.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20.0)
              btnVideos.titleLabel?.font = UIFont.systemFont(ofSize: 20.0)
            break
        case .unspecified:
            break
        case .tv:
            break
        case .carPlay:
            break
        }
       
        self.collectionView.reloadData()
    }
    
    @IBAction func btnVideosTapped(_ sender: Any) {
        flag = "Video"
        FirstView.isHidden = false
      
        leadingFirstView.constant = self.view.frame.size.width / 2
        UIView.animate(withDuration: 1, animations: {
              self.view.layoutIfNeeded()
        }, completion: nil)
        todaySpecialCall()
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
            btnVideos.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16.0)
            btnImages.titleLabel?.font = UIFont.systemFont(ofSize: 16.0)
            break
        case .pad:
            btnVideos.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20.0)
            btnImages.titleLabel?.font = UIFont.systemFont(ofSize: 20.0)
            break
        case .unspecified:
            break
        case .tv:
            break
        case .carPlay:
            break
        }
        self.collectionView.reloadData()
        
    }
    
    var imageArray = [String]()
    var todayDataSet = [TodaySpecial]()
    var totalTodayDataSet = [TodaySpecial]()
    var videoDataSet = [TodaySpecialVideos]()
    var imageDataSet = [TodaySpecialImages]()
    var totalVideosDataSet = [TodaySpecialVideos]()
    var totalImagesDataSet = [TodaySpecialImages]()
    private var collectionViewSizeChanged: Bool = false
    private var flowLayout: UICollectionViewFlowLayout!
    private let margin: CGFloat = 5.0
    var refreshControl = UIRefreshControl()
    var flag:String?
  
    @IBOutlet var popupView: UIView!
    
    @IBOutlet weak var popupImage: UIImageView!
    
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //flag = "Images"
      //  secondView.isHidden = true
        FirstView.layer.cornerRadius = 1.0
        
        setNavigate()
        title = "Today's Special"
        navigationController?.navigationBar.shadowImage = UIImage()
        
        
        imageArray = ["background_image","background_image","background_image","background_image","background_image"]
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(TodaySpecialViewController.tapFunction))
        popupImage.isUserInteractionEnabled = true
        popupImage.addGestureRecognizer(tap)
        
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
            btnImages.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16.0)
            if DeviceType.iPhone4orLess{
                  popupView.frame = CGRect(x: 0.0, y: 0.0, width:300.0 , height: 440.0 )
            }else if DeviceType.iPhone5orSE{
                  popupView.frame = CGRect(x: 0.0, y: 0.0, width: 300.0, height:520.0 )
            }else if DeviceType.iPhone678{
                  popupView.frame = CGRect(x: 0.0, y: 0.0, width: 350.0, height: 620.0)
            }else if DeviceType.iPhone678p{
                  popupView.frame = CGRect(x: 0.0, y: 0.0, width: 370.0, height: 650.0)
            }else if DeviceType.iPhoneX{
                  popupView.frame = CGRect(x: 0.0, y: 0.0, width: 350.0, height: 720.0)
            }
            break
        case .pad:
            
            if DeviceType.IS_IPAD{
               btnImages.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20.0)
                  popupView.frame = CGRect(x: 0.0, y: 0.0, width: 740.0, height: 950.0)
            }else if DeviceType.IS_IPAD_PRO{
               
                  popupView.frame = CGRect(x: 0.0, y: 0.0, width: 740.0, height: 950.0)
            }else{
                  popupView.frame = CGRect(x: 0.0, y: 0.0, width: view.frame.size.width, height: view.frame.size.height)
            }
            break
        case .unspecified:
            break
        case .tv:
            break
        case .carPlay:
            break
        }
        
        self.collectionView!.alwaysBounceVertical = true
        refreshControl.addTarget(self, action: #selector(TodaySpecialViewController.refresh(sender:)), for: UIControlEvents.valueChanged)
        collectionView.addSubview(refreshControl)
       
        todaySpecialCall()
    }
    @objc func refresh(sender:AnyObject) {
        todaySpecialCall()
        refreshControl.endRefreshing()
    }
    private func setupCollectionView() {
        flowLayout = UICollectionViewFlowLayout()
        collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: flowLayout)
        collectionView.delegate = self
        // Add collectionView as subview, create NSLayoutConstraints, set dataSource, and perform additional setup as necessary
    }
    private func setupFlowLayout() {
        flowLayout.minimumInteritemSpacing = margin
        flowLayout.minimumLineSpacing = margin
        flowLayout.sectionInset = UIEdgeInsets(top: 10.0, left: margin, bottom: margin, right: margin)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        collectionViewSizeChanged = true
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        if collectionViewSizeChanged {
            collectionView.collectionViewLayout.invalidateLayout()
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        if collectionViewSizeChanged {
            collectionViewSizeChanged = false
            collectionView.performBatchUpdates({}, completion: nil)
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        flag = "Images"
        self.leadingFirstView.constant = 0.0
    
        self.setNavigationBarItem()
        todaySpecialCall()
        self.collectionView.reloadData()
        
    }
    
    
    
    @objc func tapFunction(sender:UITapGestureRecognizer) {
        let getDataExternalUrl = UserDefaults.standard.value(forKey: "getExternalUrl")
        KGModal.sharedInstance().hide()
        
        if let anURL = URL(string: getDataExternalUrl as! String) {
            UIApplication.shared.open(anURL, options: [:], completionHandler: nil)
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if flag == "Video"{
            return self.totalVideosDataSet.count
        }else{
            return self.totalImagesDataSet.count
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "imageCell", for: indexPath as IndexPath) as! TodayList
        cell.setCardView()
//        cell.layer.masksToBounds = false
//        cell.layer.shadowRadius = 5
//        cell.layer.shadowOffset = CGSize(width:0.0,height:3.0)
//        cell.layer.shadowOpacity = 0.2
        if flag == "Video"{
            cell.img_Today.isHidden = true
            cell.webView.allowsInlineMediaPlayback = true
            let videourl = URL(string: totalVideosDataSet[indexPath.row].youtubeUrl + "?&playsinline=1&showinfo=0&volume=1")
            let requestObj = URLRequest(url: videourl!)
            cell.webView.loadRequest(requestObj)
        }else{
            cell.webView.isHidden = true
            cell.indicator.isHidden = true
            // let imageData = totalTodayDataSet[indexPath.row].images
            //cell.img_Today.image = UIImage(named: imageData)
            
            cell.img_Today.sd_setImage(with: URL(string: totalImagesDataSet[indexPath.row].images), placeholderImage: UIImage(named: "dummy_image"))
           

        }
            
        
      /*  if totalTodayDataSet[indexPath.row].adType == "2"{
//            cell.webView.allowsInlineMediaPlayback = true
//              cell.webView.loadHTMLString("<iframe width=\"\(cell.webView.frame.width)\" height=\"\(cell.webView.frame.height)\" src=\"\(totalTodayDataSet[indexPath.row].youtubeUrl)\" frameborder=\"0\" allowfullscreen=\"true\"></iframe>", baseURL: nil)
//            let youtubeVideoLink:String = totalTodayDataSet[indexPath.row].youtubeUrl
//            let str2:String = "?loop=0&amp&showinfo=1&playsinline=1"
//            let str:String = youtubeVideoLink+str2
//            let width = cell.webView.frame.width
//            let height = cell.webView.frame.height
//            let frame = 0
//            let htmlCode:String = "<iframe width=\(width) height=\(height) src=\(str) frameborder=\(frame) ></iframe>"
//            cell.webView.allowsInlineMediaPlayback = true
//            cell.webView.loadHTMLString(htmlCode as String , baseURL: nil )
//            let youtubeVideoLink:String = totalTodayDataSet[indexPath.row].youtubeUrl//"http://www.youtube.com/embed/xcJtL7QggTI"
//            let str2:String = "?&playsinline=1&showinfo=0"
//            let str:String = youtubeVideoLink+str2
//            let width = cell.webView.frame.width
//            let height = cell.webView.frame.height
//            let frame = 0
//            let htmlCode:String = "<iframe width=\(width) height=\(height) src=\(str) frameborder=\(frame) ></iframe>"
//            cell.webView.allowsInlineMediaPlayback = true
//            cell.webView.loadHTMLString(htmlCode as String , baseURL: nil )
            cell.img_Today.isHidden = true
            cell.webView.allowsInlineMediaPlayback = true
            
            let videourl = URL(string: totalTodayDataSet[indexPath.row].youtubeUrl + "?&playsinline=1&showinfo=0&volume=1")
            let requestObj = URLRequest(url: videourl!)
            cell.webView.loadRequest(requestObj)
        }else{
            cell.webView.isHidden = true
            cell.indicator.isHidden = true
           // let imageData = totalTodayDataSet[indexPath.row].images
                    //cell.img_Today.image = UIImage(named: imageData)
             cell.img_Today.sd_setImage(with: URL(string: totalTodayDataSet[indexPath.row].images), placeholderImage: UIImage(named: "dummy_image"))
//            let image = URL(string: totalTodayDataSet[indexPath.row].images)
//            let requestImages = URLRequest(url: image!)
//            cell.webView.loadRequest(requestImages)
//            cell.webView.scalesPageToFit = true
//            cell.webView.contentMode = UIViewContentMode.scaleAspectFit
        } */
//        let imageData = imageArray[indexPath.row]
//        cell.img_Today.image = UIImage(named: imageData)
       // cell.webView.load(<#T##request: URLRequest##URLRequest#>)
       
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var size = CGSize()
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
            if flag == "Video"{
               
                size = CGSize(width: (view.frame.size.width-35) , height:150)
            }else{
                size = CGSize(width: (view.frame.size.width-35) / 2, height:150)
               
            }
            
            break
        case .pad:
            if DeviceType.IS_IPAD{
                if flag == "Video"{
                    size = CGSize(width: (view.frame.size.width-35), height:300)
                }else{
                    size = CGSize(width: (view.frame.size.width-35) / 2, height:300)
                }
                
              
            }else{
                if flag == "Video"{
                    size = CGSize(width: (view.frame.size.width-35), height:350)
                }else{
                    size = CGSize(width: (view.frame.size.width-35) / 2, height:350)
                }
                // size = CGSize(width: (view.frame.size.width-20), height:350)
            }
            
            break
        case .unspecified:
            break
        case .tv:
            break
        case .carPlay:
            break
        }
        return size
        //return CGSize(width: (view.frame.size.width-15) / 2, height: view.frame.size.height/5)
        //return CGSize(width: (view.frame.size.width-20), height:150)
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
         let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "imageCell", for: indexPath as IndexPath) as! TodayList
        
//        videoCell.playerView.player?.pause();
//        videoCell.playerView.player = nil;
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
//        let getImageUrl = totalTodayDataSet[indexPath.row].images
//        UserDefaults.standard.set(getImageUrl, forKey: "getImageUrl")
//        self.popupImage.image = UIImage(named: getImageUrl)
        self.popupImage.sd_setImage(with: URL(string: totalImagesDataSet[indexPath.row].images), placeholderImage: UIImage(named: "dummy_image"))
        if totalImagesDataSet[indexPath.row].adType == "2"{

        }else{
            
            let getExternalUrl = totalImagesDataSet[indexPath.row].externalUrl
             UserDefaults.standard.set(getExternalUrl, forKey: "getExternalUrl")
            KGModal.sharedInstance().show(withContentView: self.popupView, andAnimated: true)
            KGModal.sharedInstance().closeButtonType = .left
            KGModal.sharedInstance().tapOutsideToDismiss = true
            KGModal.sharedInstance().modalBackgroundColor = UIColor.clear

        }
        print("You tapped cell number \(indexPath.row).")
    }
    func todaySpecialCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.todays_specials)
        
        requestGETURL(url, params: nil, success: { (data) in
            print("data = >",data)
            let status = data["status"].boolValue
            if !status{
                
            }else{
                self.imageDataSet.removeAll()
                self.videoDataSet.removeAll()
                var dataIterator = 0
                for specialList in data["resultdata"].arrayValue{
                    
                   let externalUrl = specialList["external_url"].stringValue
                    let adType = specialList["ad_type"].stringValue
                    let youtubeUrl = specialList["youtube_url"].stringValue
                    let images = specialList["image"].stringValue
                    
                    
                    if images == ""{
                        if self.flag == "Video"{
                            
                        }else{
                            self.popupAlert(title: "Hero Habit", message: "No Ads", actionTitles: ["Ok"], actions:[{ (action1) in
                                
                                }])
                        }
                    }else{
                      self.imageDataSet.append(TodaySpecialImages(ad_type: adType, external_url: externalUrl, image: images))
                    }
                    
                    if youtubeUrl == ""{
                        if self.flag == "Video"{
                            self.popupAlert(title: "Hero Habit", message: "No Videos", actionTitles: ["Ok"], actions:[{ (action1) in
                                
                                }])
                        }else{
                            
                        }
                       
                    }else{
                        self.videoDataSet.append(TodaySpecialVideos(ad_type: adType, external_url: externalUrl, youtube_url: youtubeUrl))
                    }
                    
                    self.totalImagesDataSet = self.imageDataSet
                    self.totalVideosDataSet = self.videoDataSet
                    
                    dataIterator = dataIterator + 1
                    
                }
                
            }
            self.collectionView.reloadData()
        }) { (error) in
            print(error)
        }
    }
   
}
class TodaySpecial{
    let adType:String
    let externalUrl:String
    let youtubeUrl:String
    let images:String
    init(ad_type:String,external_url:String,youtube_url:String,image:String) {
        self.adType = ad_type
        self.externalUrl = external_url
        self.youtubeUrl = youtube_url
        self.images = image
    }
}
class TodaySpecialVideos{
    let adType:String
    let externalUrl:String
    let youtubeUrl:String
    
    init(ad_type:String,external_url:String,youtube_url:String) {
        self.adType = ad_type
        self.externalUrl = external_url
        self.youtubeUrl = youtube_url
        
    }
}
class TodaySpecialImages{
    let adType:String
    let externalUrl:String
     let images:String
    
    init(ad_type:String,external_url:String,image:String) {
        self.adType = ad_type
        self.externalUrl = external_url
        self.images = image
        
    }
}
