//
//  Constant.swift
//  HeroHabits
//
//  Created by aspl on 31/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import Foundation
import UIKit

class webConstant:NSObject
{

    static let baseUrl = "http://server.ashoresystems.com/~herohabit/webservices/"
    static let sign_up = "signup"
    static let sign_in = "signin"
    static let forgot_password = "forgot_password"
    static let change_password = "change_password"
    static let update_email = "update_email"
    static let update_Profile = "update_profile"
    static let about_Us = "about_us"
    static let contact_us = "contact_us"
    static let contact_us_detail = "contact_us_detail"
    static let profile_Details = "profile_details"
    static let categoryList = "category_list"
    
    static let activity_list = "activity_list"
    static let add_category = "add_category"
    static let add_activity = "add_activity"
    static let delete_category = "delete_user_category"
    static let delete_activity = "delete_user_activity"
    static let user_category_list = "user_category_list"
    static let user_activity_list = "user_activity_list"
     static let add_habit = "add_habit"
     static let habit_list = "habit_list"
     static let allHabit_list = "allhabit_list"
     static let delete_habit = "delete_habit"
     static let update_habit = "update_habit"
    static let add_notes = "add_notes"
    static let habit_Details = "gethabit_details"
    static let edit_note = "edit_note"
    static let verifyemail = "verifyemail"
    static let deleteNotes = "delete_note"
    static let update_sequence_no = "update_sequence_no"
    static let summary = "summary"
    static let todays_specials = "todays_specials"
    static let invite_others = "invite_others"
}

enum UIUserInterfaceIdiom : Int {
    case unspecified
    case phone // iPhone and iPod touch style UI
    case pad // iPad style UI
}


