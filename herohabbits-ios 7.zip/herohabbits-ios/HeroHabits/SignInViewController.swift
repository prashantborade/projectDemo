//
//  SignInViewController.swift
//  HeroHabits
//
//  Created by aspl on 25/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit
import SlideMenuControllerSwift
import Alamofire
import SwiftyJSON
import GoogleSignIn


class SignInViewController: UIViewController,UITextFieldDelegate,GIDSignInUIDelegate,GIDSignInDelegate{
     var isLoginFrom: String = ""
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var btnSignUp: UIButton!
    
    @IBOutlet weak var lblSignUp: UILabel!
    
    @IBOutlet weak var heightOfImage: NSLayoutConstraint!
    
    @IBOutlet weak var widthOfImage: NSLayoutConstraint!
    var tField: UITextField!
    
    @IBOutlet weak var heightOftxtfield: NSLayoutConstraint!
    
    @IBOutlet weak var heightOfbtn: NSLayoutConstraint!
    
    @IBOutlet weak var heightOfGoogle: NSLayoutConstraint!
    
    @IBOutlet weak var widthOfGoogle: NSLayoutConstraint!
    
    @IBOutlet weak var heightOfTwitter: NSLayoutConstraint!
    
    @IBOutlet weak var widthOfTwitter: NSLayoutConstraint!
    
    @IBOutlet weak var verticalSpaceOfImage: NSLayoutConstraint!
    
    @IBOutlet weak var widthOfSocial: NSLayoutConstraint!
    
    @IBOutlet weak var heightOfSocial: NSLayoutConstraint!
    //MARK:Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        txtPassword.delegate = self
        
        lblSignUp.text = "New User ? Sign Up"
        let text = (lblSignUp.text)!
        let underlineAttriString = NSMutableAttributedString(string: text)
        let range1 = (text as NSString).range(of: "Sign Up")
        underlineAttriString.addAttribute(NSAttributedStringKey.foregroundColor, value: UIColor.white , range: range1)
        lblSignUp.attributedText = underlineAttriString
        
        let tapSignUp = UITapGestureRecognizer(target: self, action: #selector(SignInViewController.tapSignUp))
        lblSignUp.isUserInteractionEnabled = true
        lblSignUp.addGestureRecognizer(tapSignUp)
        
        
        
    }

    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
        txtUserName.delegate = self
        txtPassword.delegate = self
        txtPassword.text = nil
        txtUserName.text = nil
        switch UIDevice.current.userInterfaceIdiom {
            
        case .unspecified:
            break
        case .phone:
            break
        case .pad:
            if DeviceType.IS_IPAD_PRO{
                verticalSpaceOfImage.constant = 150.0
                heightOfImage.constant = 250.0
                widthOfImage.constant = 250.0
                heightOftxtfield.constant = 50.0
                heightOfbtn.constant = 50.0
                heightOfGoogle.constant = 80.0
                heightOfTwitter.constant = 80.0
                widthOfGoogle.constant = 60.0
                widthOfTwitter.constant = 60.0
                heightOfSocial.constant = 84.0
                widthOfSocial.constant = 180.0
            }else if DeviceType.IS_IPAD{
                verticalSpaceOfImage.constant = 100.0
                heightOfImage.constant = 200.0
                widthOfImage.constant = 200.0
                heightOftxtfield.constant = 50.0
                heightOfbtn.constant = 50.0
                heightOfGoogle.constant = 80.0
                heightOfTwitter.constant = 80.0
                widthOfGoogle.constant = 60.0
                widthOfTwitter.constant = 60.0
                heightOfSocial.constant = 84.0
                widthOfSocial.constant = 180.0
            }
        case .tv:
            break
        case .carPlay:
            break
        }
        
        self.slideMenuController()?.removeLeftGestures()
       
    }


//MARK:Button Action
    @objc func tapSignUp(sender:UITapGestureRecognizer){
        let text = (lblSignUp.text)!
        let termsRange = (text as NSString).range(of: "Sign Up")
        
        if sender.didTapAttributedTextInLabel(label: lblSignUp, inRange: termsRange) {
            print("Tapped Sign Up")
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
            self.navigationController?.pushViewController(controller, animated: true)
           
        }else {
            print("Tapped none")
        }
    }


    @IBAction func btnSignInTapped(_ sender: Any) {
        
        guard let firstName = txtUserName.text, !firstName.isEmpty else {
            popupAlert(title: "Hero Habits", message: "Please Enter Your Username", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
            return
        }
        
       
       
        guard let password = txtPassword.text, !password.isEmpty else {
            popupAlert(title: "Hero Habits", message: "Please Enter Your Password", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in

                }])
            return
        }
        
        guard let parse = txtPassword.text, !(parse.rangeOfCharacter(from: NSCharacterSet.whitespaces) != nil) else {
            popupAlert(title: "Hero Habit", message: "Password do not accept space as Password", actionTitles: ["Ok"], actions: [{(action1) in
                
                }])
            return
        }
       

        signInCall()
        
    }
    
    @IBAction func btnForgotTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "ForgotPasswordViewController") as! ForgotPasswordViewController
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    
    @IBAction func btnTwitterTapped(_ sender: Any) {
      
        self.isLoginFrom = "Twitter"
        UserDefaults.standard.set(self.isLoginFrom, forKey: "isLoginFrom")
        if (UIApplication.shared.canOpenURL(URL(string:"twitter://")!)) {
        TWTRTwitter.sharedInstance().logIn(completion: { (session, error) in

            if (session != nil) {
                print("signed in as \(String(describing: session?.userName))");
                SVProgressHUD.dismiss()
                
                    var url = webConstant.baseUrl
                    url.append(webConstant.sign_up)

                    let params:Dictionary  = ["first_name":"",
                                              "last_name":"",
                                              "email":"",
                                              "dob":"",
                                              "password":"",
                                              "username":(session?.userName)!,
                                              "login_type":"3"]

                    print("params",params)
                    
                    requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
                        print(data)
                        let status = data["status"].boolValue
                        let message = data["message"].stringValue
                        if !status{
                            self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                                
                            }])
                        }else{
                            let username = data["resultdata"]["username"].stringValue
                            let userID = data["resultdata"]["user_id"].stringValue
                            let eamilID = data["resultdata"]["email"].stringValue
                            
                            UserDefaults.standard.set(userID, forKey: "userID")
                            UserDefaults.standard.set(username, forKey: "userName")
                            
                            if (eamilID.count == 0){
                                self.gettwittercall()
                            }else{
                                UserDefaults.standard.set(true, forKey: "mainController")
                                let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                                objAppDelegate?.gotoMainController()
                            }
                        }
                    }, failure: { (error) in
                        print(error)
                    })
                   
            } else {

                self.popupAlert(title: "Hero Habit", message: String(describing: error!.localizedDescription), actionTitles: ["Ok"], actions: [{ (action1) in

                }])
                print("error: \(String(describing: error?.localizedDescription))");
            }
        })
        }else{
            self.popupAlert(title: "Hero Habit", message: "Please,install twitter app.", actionTitles: ["Ok"], actions: [{ (action1) in
                
                }])
        }
    }
    
    @IBAction func btnGoogleSignIn(_ sender: Any) {
         GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().delegate = self
       GIDSignIn.sharedInstance().signIn()
        isLoginFrom = "Google"
        UserDefaults.standard.set(isLoginFrom, forKey: "isLoginFrom")
    }
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            print("\(error.localizedDescription)")
        } else {
            // Perform any operations on signed in user here.
//            let userId = user.userID                  // For client-side use only!
//           // let idToken = user.authentication.idToken // Safe to send to the server
//            let fullName = user.profile.name
//            let givenName = user.profile.givenName
//            let familyName = user.profile.familyName
//            let email = user.profile.email
            // ...
            
            let userId :String = user.userID                  // For client-side use only!
            // let idToken :String = user.authentication.idToken // Safe to send to the server
            
            let image :URL = user.profile.imageURL(withDimension: 1)
            let fullName :String = user.profile.name
            let givenName :String = user.profile.givenName
            let familyName :String = user.profile.familyName
            let email :String = user.profile.email
            
          print("email",email,"userid",userId, "userid",userId ,"fullName",fullName, "givenName",givenName,"familyName",familyName, "image",image )
            
                var url = webConstant.baseUrl
                url.append(webConstant.sign_up)
                
                let params:Dictionary  = ["first_name":givenName,
                                          "last_name":familyName,
                                          "email":email,
                                          "dob":"",
                                          "password":"",
                                          "username":givenName,
                                          "login_type":"4"]
                
                requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
                    print(data)
                    let status = data["status"].boolValue
                    let message = data["message"].stringValue
                    if !status{
                        self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                            
                            }])
                    }else{
                        
                        let username = data["resultdata"]["username"].stringValue
                        let userID = data["resultdata"]["user_id"].stringValue
                        let eamilID = data["resultdata"]["email"].stringValue
                        
                        UserDefaults.standard.set(userID, forKey: "userID")
                        UserDefaults.standard.set(username, forKey: "userName")
                        
                        if (eamilID.count == 0){
                             self.gettwittercall()
                        }else{
                            UserDefaults.standard.set(true, forKey: "mainController")
                            let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                            objAppDelegate?.gotoMainController()
                        }
                    }
                }) { (error) in
                    print(error)
                }
                
            
        }
    }
    
    // Present a view that prompts the user to sign in with Google
    func sign(_ signIn: GIDSignIn!,
              present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    private func signIn(signIn: GIDSignIn!,
                dismissViewController viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //MARK: Webservice Call
    func signInCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.sign_in)
        
        let params = ["username":txtUserName.text!,
                                  "password":txtPassword.text!]
        
        requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
            print(data)
            let status = data["status"].boolValue
            let message  = data["message"].stringValue
            if !status{
                self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                    
                    }])
            }else{
                 let userID = data["resultdata"]["user_id"].stringValue
                let username = data["resultdata"]["username"].stringValue
                
                UserDefaults.standard.set(userID, forKey: "userID")
                UserDefaults.standard.set(username, forKey: "userName")
                UserDefaults.standard.set(true, forKey: "mainController")
                //  UserDefaults.standard.set("", forKey: "profileImage")
                let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                objAppDelegate?.gotoMainController()
            }
        }) { (error) in
            print(error)
        }
    }
    
    
    func gettwittercall()
    {
        func configurationTextField(textField: UITextField!)
        {
            print("generating the TextField")
            textField.placeholder = "Enter an Email id"
            self.tField = textField
        }
        
        func handleCancel(alertView: UIAlertAction!)
        {
            print("Cancelled !!")
        }
        
        let alert = UIAlertController(title: "Enter Email address", message: "", preferredStyle: .alert)
        alert.addTextField(configurationHandler: configurationTextField)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler:handleCancel))
        alert.addAction(UIAlertAction(title: "Done", style: .default, handler:{ (UIAlertAction) in
            print("Done !!")
            
            if(!self.isValidEmail(testStr:  self.tField.text!))
            {
                self.popupAlert(title: "Hero Habits", message: "Please Enter Correct E-mail Address", actionTitles: ["Ok"], actions: [{ (action1) in
                    print("ok")
                    },{(action2) in
                    print("ok2")
                    }])
                
            }else{
                self.serviceCall()
            }
        }))
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }

    func serviceCall(){
   
    print("emailId : \(String(describing: self.tField.text))")
    let emailId : String = self.tField.text!
    print("emailId ->",emailId )
   
        var url = webConstant.baseUrl
        url.append(webConstant.update_email)
       
        let user_id = UserDefaults.standard.value(forKey: "userID") as! String
        let params = ["email":emailId,
                                   "id":user_id]
        
        
      
        requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
            print(data)
            let resp = data["resp"].boolValue
            let message = data["message"].stringValue
            if !resp{
                self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions: [{ (action1) in
                    
                    }])
            }else{
                let userID = data["result"]["user_id"].stringValue
                let username = data["result"]["username"].stringValue
                
                UserDefaults.standard.set(userID, forKey: "userID")
                UserDefaults.standard.set(username, forKey: "userName")
                UserDefaults.standard.set(true, forKey: "mainController")
                
                let objAppDelegate = (UIApplication.shared.delegate as? AppDelegate)
                objAppDelegate?.gotoMainController()
            }
        }) { (error) in
            print(error)
        }
    }
}

