//
//  ForgotPasswordViewController.swift
//  HeroHabits
//
//  Created by aspl on 29/05/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController {

    @IBOutlet weak var btnSend: UIButton!
    @IBOutlet weak var txtUsername: TextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = false
        setNavigate()
        title = "Forgot Password"
        
        
        btnSend.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
      
    }
    
    @objc func buttonAction(sender: UIButton!) {
        guard let firstName = txtUsername.text, !firstName.isEmpty else {
            popupAlert(title: "Hero Habits", message: "Please Enter Your User Name", actionTitles: ["Ok"], actions: [{ (action1) in
                },{(action2) in
                    
                }])
            return
        }
        
        
        forgotPasswordCall()
        
    }
    
    func forgotPasswordCall(){
        var url = webConstant.baseUrl
        url.append(webConstant.forgot_password)
        
        let params:Dictionary  = ["username":txtUsername.text!]
        
        requestPOSTURL(url, params: params as [String : AnyObject], success: { (data) in
            print(data)
            let resp = data["resp"].boolValue
            let message = data["message"].stringValue
            if !resp{
                
            }else{
                self.popupAlert(title: "Hero Habit", message: message, actionTitles: ["Ok"], actions:[{(action) in
                    self.navigationController?.popViewController(animated: true)
                    }])
            }
        }) { (error) in
            print(error)
        }
        
    }
  

}
