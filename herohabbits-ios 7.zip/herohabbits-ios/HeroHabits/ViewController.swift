//
//  ViewController.swift
//  HeroHabits
//
//  Created by aspl on 14/06/18.
//  Copyright © 2018 aspl. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var heightOfView: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 900
        switch UIDevice.current.userInterfaceIdiom {
        case .phone:
            break
        // It's an iPhone
        case .pad:
            tableView.rowHeight = 1200
            tableView.estimatedRowHeight = 1200
            break
        // It's an iPad
        case .unspecified: break
        // Uh, oh! What could it be?
        case .tv:
            break
        case .carPlay:
            break
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        return cell
    }

}
